# AAOS Commercial UI Audit and Implementation Receipt

Date: 2026-09-23
Scope: `apps/ArcheAxis.Desktop/` and the AAOS portions of `D:\All projects\UI套件`
Audit model: `gpt-6-astra`
Reasoning: `medium`
Evidence level: `READ_ONLY_AUDIT` plus the implementation and local gates listed below

## Reference package findings

The AAOS UI package contains more than color references. The audited package
index and AAOS prompt identify page compositions, component contracts, state
machines, focus behavior, responsive rules, and interaction examples. The B04
tokens include 120/180/280/420ms motion bands. B06 covers hover, focus, pressed,
drawer, modal, toast, loading, empty, error, permission and responsive states.
B09 and B10 contain interaction demonstrations including citation insertion,
review flow, command palette, graph-node interaction, card flip, drawer and
low-frequency ambient motion.

The demo code is reference material only. Its localStorage state, random graph
values and simplified review behavior are not Core truth and are not copied into
the desktop product.

## Implemented in this slice

- Added a project-owned generated empty-state illustration at
  `apps/ArcheAxis.Desktop/Assets/aaos-knowledge-constellation-empty-state.png`.
  It is decorative only and is not evidence, a metric, or a fabricated Core
  projection.
- Added semantic motion resources, a restrained opacity transition, selected
  FSRS grade feedback, a reduced-motion environment switch
  (`AAOS_REDUCED_MOTION=1`), and a high-contrast primary-action text brush.
- Learning navigation now calls the existing Core learning read path on entry.
- Recovery navigation now calls the existing read-only recovery boundary read
  on entry.
- The empty learning queue now exposes Library and Jobs next actions.
- Review grade controls reflow to one column at narrow widths and expose stable
  automation names. FSRS grade selection no longer changes the independent
  Core correctness selection.
- Learning now renders the real Core queue as a selectable list instead of
  always pinning the first item; selection reuses the existing item/state/
  assessment/readback routes.
- Evidence Center now has a product-level unavailable empty state with the
  generated visual and truthful Capture/Jobs next actions; it still does not
  fabricate evidence rows while the Core read model is absent.
- Home now has a responsive product hero using the same project-owned visual;
  the asset remains decorative and the actions route to real Capture/Library
  surfaces.
- Research, Plugins and Models now use a shared product-level unavailable state
  with truthful boundary copy and return/system next actions instead of a blank
  prototype panel.
- The Review surface now presents user-facing labels for answer result and
  review difficulty; Core/FSRS technical semantics remain in the supporting
  receipt text rather than dominating the primary interaction.

## Verified locally

- Avalonia Debug build: `PASS`, 0 warnings, 0 errors.
- Avalonia self-contained `win-x64` Release publish: `PASS`; output was
  `.project-local/build/desktop-publish/ui-commercial-pass-2/`.
- Targeted desktop contracts: `142 passed` with the project-local candidate
  Python and ephemeral pytest environment.
- Headless Core learning smoke with the explicit project-local database and
  worker profile: `PASS`; `answer_saved=true`, `fsrs=true`, and
  `mastery_projection_closed=false` (the last value is correctly not promoted
  to mastery completion).
- `git diff --check`: `PASS` for the current diff.

## Still open and intentionally not overstated

- Native GUI screenshot, click-through and accessibility readback:
  `NOT_EXECUTED/UNVERIFIED`; the current CUA bridge exposed no native window.
- Evidence Center remains an explicit Core-contract `UNAVAILABLE` state because
  the current Core does not expose the required evidence list read model. No
  synthetic anchors or bundles were introduced.
- Full Learning Golden Journey with real Core data and cold restart remains
  separate from build/static contract evidence.
- The complete 13-route UI suite mapping, Memory Map, Original Editor and
  citation picker are not claimed complete by this receipt.

## Boundary

No Green directory, external data/model/tool library, E/F drive, credential,
history asset or private session state was modified. This audit does not approve
bulk deletion, branch merge, release publication, signing or Green overwrite.

## Current frontend follow-up — 2026-09-23

The implementation advanced after this audit snapshot. The current frontend
source baseline remains `67499def`; the current delivery head is
`a9860ce0a9c59855e4daa692d12cb03e7f588243`, with `201` direct no-argument
static desktop contract tests recorded. Search responses are stale-request
isolated; the mobile Inspector overlays the workspace safely, enters focus,
scrolls long content and reflows actions; Source Reader stacks below the themed
`1200px` breakpoint.

The project-local Candidate `p3-9654023a` now includes Desktop, rebuilt Core,
runtime, workers and the FSRS donor. Static verification returned
`ok=true`/`21473` files, and the staged package's Desktop learning smoke
returned `LEARNING SMOKE OK` with `answer_saved=true`, `fsrs=true` and
`mastery_projection_closed=false`. Native pointer/focus/accessibility readback
remains `UNVERIFIED`: the current Windows bridge exposes no targetable native
apps, and the captured screen is visual observation only.

### Historical output location update — 2026-09-30

The historical `.project-local/build/desktop-publish/ui-commercial-pass-2` output cited above is now stored under the `ui-commercial-pass-2/` member prefix in the verified archive. Original evidence text and acceptance status are unchanged. Restore before rerunning; archive SHA, exact paths and recovery instructions are in [the storage audit](../history/storage-cleanup/2026-09-30/desktop-publish-history-archive-20260930.md). This note does not assert a current product/runtime PASS.
