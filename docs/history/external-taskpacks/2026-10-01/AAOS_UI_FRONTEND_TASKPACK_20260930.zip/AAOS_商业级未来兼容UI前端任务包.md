# AAOS — 商业级未来兼容UI前端任务包

日期：2026-09-30。交付范围：现有前端改造；不是研究报告，也不宣称本包附带已实现源码。

## AAOS / ArcheAxis 产品裁决
在现有 ArcheAxis 正式前端上采用 Current Core + Future Capability 双层结构。具体已存在一级导航必须先从 live 代码及 9/28 UI 包恢复，不凭本包重建旧菜单。主工作区保留知识沉淀、学习、搜索/检索、管线和现有模型底座的真实实现；蓝图能力进入统一 Capability Atlas，可按学习、知识、管线、模型、Agent、评测、吸收池分类，分类由历史权威确认。
首页是继续当前工作、最近知识/管线任务、真实健康、待处理和证据，不是静态宇宙海报。全局 Shell：左侧现有导航分组、顶部项目/范围/搜索/命令、中心工作面、右侧可折叠上下文/证据 Inspector。Current 与 Future 显式区分；Future 默认只读，点击进入能力详情，展示历史来源、实施状态、依赖和原接口占位，不显示假运行按钮。

## 核心工作面
知识与学习页：真实来源、入库状态、索引版本、引用定位、更新时间、质量与冲突；检索结果可打开来源和证据。管线页：已有真实 steps、输入输出、运行/失败/阻塞、日志、receipt、重跑权限和结果 readback。模型页：保留已有共用模型库路径、adapter、模型 identity、版本、体积和探测；观察不到的配置为 UNKNOWN。WORK-LAB 负责共用部署/调度，AAOS 保留知识模型底座与管线测试责任，不重复实现另一套全局 launcher/provider authority。
历史吸收池展示 proposed/evaluating/adopted/rejected 和出处，adopted 必须有实现证据。不得把调研项目冒充已集成。科研/本地/免费模型蓝图可以预留界面但不默认下载大模型、不自动安装。

## VI 与动态替换
复用 AAOS 当前权威 tokens/B10 及历史 UI 包，金青体系如与 live tokens 冲突，以当前 Authority 和用户确认的 VI 为准。所有生成的静态数据配图逐项移除：知识地图→可选节点与引用关系 SVG；管线概览→真实状态边与步骤面板；模型能力→可筛选能力矩阵；蓝图总览→可交互星座/轨道图及可访问列表；空状态→轻量矢量和明确行动。保留用户真实参考/成果图，不能把所有业务图片误删。
UI02 用于局部状态控件，UI03/UI04/UI05 只有现有 React 栈匹配时复制代码；非 React 使用 UI11/SVG/CSS 重建相同行为。不因动效重写框架。星空不遮挡检索阅读，金/青用于品牌和语义重点，状态另用绿/黄/红。知识图支持 zoom/pan、键盘列表、节点筛选、来源 Inspector；性能不足自动降级列表。

## AAOS 必须交付
恢复全部历史导航到 live route 对照；Current/Future 能力来源与实现映射；静态配图替换矩阵；真实知识/检索/管线主流程；原接口兼容；动态地图的无动效降级；Windows 视觉与 IME；生产构建和重启恢复。最终状态 `AAOS_FRONTEND_COMMERCIAL_RC_READY`。输出 AAOS_FRONTEND_COMPLETION_REPORT.md、AAOS_FINAL_IA.md、AAOS_CAPABILITY_UI_MATRIX.md、AAOS_VISUAL_QA.md、AAOS_ASSET_MANIFEST.json、AAOS_MERGE_READY_HANDOFF.md。没有读取历史文件或执行某项测试须如实注明，不能用本包替代验证。

## 执行权威与边界
本包依据本轮完整对话编制，是前端实施指令，不宣称已重新审计云端仓库，也不替代仓库 Authority。执行器必须先读取 LIVE origin/main、AUTHORITY.md、authority index、AGENTS.md、当前 TaskPack、真实 API/contracts 和正式前端代码，再读取 2026-09-28–29 的本项目 Master Atlas、历史补充与 UI 包。未能读取的来源登记 MISSING，不得编造。历史蓝图不是实现证据；最新 Authority 决定是否可执行，用户当前要求决定本轮产品范围。冲突列明具体文件、条款及代码证据，在不受影响的范围继续推进。

只在现有正式前端修复、集成和更新，不创建第二 frontend、runtime、task ledger、evidence store、config authority 或全局 design system。保留 route、API、contract、索引 ID、路径、深链及持久化 identity。使用独立 UI 分支/worktree；先记录 branch/SHA/dirty，保护未提交工作，不直接修改 main，不自行 merge/release。执行器可用 Codex、Hermes、DSH，模型不锁死。

## 接口和未来能力契约
改代码前生成逐项兼容矩阵：原 route/别名、组件实际路径、API method/path、request/response schema、service authority、权限、deep link、存储 key、现有测试、变更后位置、兼容策略。本包不虚构项目内部路径。重组导航只改变展示分组，旧 route 保持或采用有测试的兼容别名，不静默删除。
能力条目复用现有 schema；确需扩展时提交最小 ADR。字段至少含稳定 capabilityId、domain、来源、owner、route、contractRef、implementationState、availability、permission、lastProbe、evidenceRef、reason、nextAction。实施状态与运行可用状态分离：PLANNED/EXPERIMENTAL/IMPLEMENTED 和 UNKNOWN/AVAILABLE/STALE/OFFLINE/BLOCKED。无 backend 的蓝图页提供目标、依赖、接入点、来源及只读说明，不伪造成功或可执行按钮。未来能力只引用单一现有登记表，不创建平行账本。

## 开源供应链：先复用，再定制
按以下索引先读取官方组件和源码；只下载实际需要的组件，不把整个示例应用复制为新前端。每项集成记录索引 ID、official URL、固定 commit/version、LICENSE 和文件级版权、source 文件、目标路径、token remap、依赖、大小、修改点与测试。免费展示不等于允许源码再分发；付费模板不下载不打包。第三方 logo 遵循商标要求，不确定时用通用 glyph + text。

| ID | 官方入口 | 用途与集成限制 |
|---|---|---|
| UI01 | https://github.com/shadcn-ui/ui ; https://ui.shadcn.com/docs | React 正式栈的 Button/Dialog/Drawer/Command/Table/Sidebar primitives；已有实现优先保留 |
| UI02 | https://github.com/uiverse-io/galaxy ; https://uiverse.io | GALAXY 指 UI 元素库，不代表星空引擎；选择 CSS/Tailwind 状态控件、进度和卡片，逐项确认许可 |
| UI03 | https://github.com/magicuidesign/magicui ; https://magicui.design | Orbiting Circles/Animated Beam 等动态元素候选；先核实官方当前 registry 和组件文件，不猜安装 URL |
| UI04 | https://github.com/DavidHDev/react-bits ; https://reactbits.dev | 粒子/星空/交互效果参考；核查当前 LICENSE，React 代码不能直接塞入非 React 前端 |
| UI05 | https://ui.aceternity.com/components ; https://ui.aceternity.com/licence | Stars/Beams/Card 效果候选；免费与 Pro、产品使用与源码分发须分开核查 |
| UI06 | https://github.com/DouyinFE/semi-design ; https://semi.design | 成品表格/表单/布局参考；React 项目也不整体引入第二设计系统，非 React 项目只参考行为 |
| UI07 | https://tailwindcss.com/docs | 只沿用仓库现有 Tailwind 版本，禁止为素材强行升级全项目 |
| UI08 | https://github.com/adobe/spectrum-web-components ; https://opensource.adobe.com/spectrum-web-components/ | DESIGN-LAB 原生 Web Components 兼容试验候选 |
| UI09 | https://github.com/shoelace-style/webawesome ; https://webawesome.com | DESIGN-LAB Web Awesome Core 兼容试验候选；只选择允许使用的 Core 部分 |
| UI10 | https://github.com/xyflow/xyflow ; https://reactflow.dev | React 节点工作流候选；只有既有 contract 和明确编辑权限才提供写操作 |
| UI11 | https://github.com/d3/d3 ; https://d3js.org | 非 React 数据网络、布局和可视化候选；SVG/Canvas 可保留原技术栈 |
| UI12 | https://github.com/penpot/penpot | 专业设计工作台布局与 Inspector 行为参考；不复制整个产品，核查具体源码许可 |
| UI13 | https://github.com/langgenius/dify ; https://github.com/n8n-io/n8n | 工作流、执行详情和治理 UX 参考；并非统一宽松开源授权，不直接复制受限制素材 |
| UI14 | https://github.com/lucide-icons/lucide ; https://lucide.dev | 优先复用现有图标体系，非 React 使用对应 vanilla 入口 |

执行顺序：读取官方源码/registry→确认许可和依赖→固定版本→下载到临时来源目录→复制最小文件到既有 components 路径→替换品牌 tokens→连接真实 adapters→测试→移除未采用临时素材。源码可用 `git clone --depth 1 <上表官方仓库URL> <临时来源目录>` 获取，随后记录 `git rev-parse HEAD`，不要把浮动 main 当长期锁定版本。React 项目若已配置 shadcn，可使用 `pnpm dlx shadcn@<已核实版本> add button dialog sheet command tabs tooltip table`，运行前核查 components.json 和覆盖清单。其他 registry 必须以官方当前命令为准；不猜 URL，不盲目运行远程 shell。依赖安装使用仓库锁文件和包管理器，不自动下载新工具链。最终保留 license attribution。

## 动态视觉统一要求
产品主体必须是可交互组件，不用生成的静态配图承载数据、状态、流程或能力地图。星空、星环、轨道、粒子、星座节点可以复用，作为局部品牌氛围和有意义的数据视图；布局、文字、卡片和主要操作始终清晰。点击节点进入已有详情，hover/focus 显示真实证据，筛选影响真实数据。轨道运动不可伪装执行进度；无数据使用明确 empty/unknown。
按组件登记静态旧图→替换位置→真实数据源→交互→动效→降级方案。装饰动画与语义动画分开：装饰可关闭，语义对应真实状态。优先 SVG/CSS/Canvas，WebGL 仅在有测量收益时采用。后台/不可见时暂停，避免每张卡独立渲染循环。支持 prefers-reduced-motion、高对比度、键盘和读屏；简化动画后仍能理解所有状态。不自动引入重型 3D runtime。

## 商业级状态与验收
所有页面覆盖 loading、empty、success、partial、error、offline、stale、permission denied、conflict 和 recovery；无数据不造 KPI。真实写操作统一经现有服务→执行→receipt→readback，处理重复提交、超时 outcome unknown、重启恢复；不能用 toast 当成功证据。保留用户上下文和选中项。
先完成 shell/核心工作面，再按合同接通页面，再加动效和供应链元素。每阶段提交可审查 diff，记录文件、接口、截图、命令结果和阻塞。执行仓库已有 typecheck/unit/build/E2E；不在脚本未知时杜撰命令。验证 route 深链、刷新、持久化、offline、CSP、键盘、焦点恢复、Escape、Ctrl/Cmd+K、aria-current/live、中文 IME、125%/150% DPI、深浅色和 reduced motion。Windows 专属测试须真实 Windows 执行；Linux 结果不得写成 Windows PASS。缺环境可完成其余工作并交付明确 BLOCKED，不虚报 RC_READY。
截图保留 1280×820、1920×1080、2560×1440 和指定窄屏，覆盖关键成功/失败/空状态。最终交付源码 diff、兼容矩阵、来源许可清单、测试证据、截图矩阵、回滚路径及 merge-ready handoff；报告可由执行器在仓库生成，本下载包本身只含两份 Markdown。只有所有实际 DoD 达成才标记各项目 COMMERCIAL_RC_READY。
