from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VIEW = ROOT / "apps" / "ArcheAxis.Desktop" / "AaosReviewScheduleChart.axaml"
CODE = ROOT / "apps" / "ArcheAxis.Desktop" / "AaosReviewScheduleChart.axaml.cs"


def test_review_schedule_chart_is_an_empty_seven_bar_master_silhouette() -> None:
    root = ET.parse(VIEW).getroot()
    bars = [node for node in root.iter() if "review-schedule-bar" in node.get("Classes", "").split()]
    text_blocks = [node.get("Text", "") for node in root.iter() if node.tag.endswith("TextBlock")]

    assert root.get("{http://schemas.microsoft.com/winfx/2006/xaml}Class") == "ArcheAxis.Desktop.AaosReviewScheduleChart"
    assert len(bars) == 7
    assert "等待 Core 复习历史；柱体仅为布局轮廓，不代表指标" in text_blocks
    assert all(text == "等待 Core 复习历史；柱体仅为布局轮廓，不代表指标" for text in text_blocks)
    assert not any(node.tag.endswith(("Polyline", "Path", "Line", "TextBox")) for node in root.iter())
    assert not re.search(r"\b(?:19|20)\d{2}[-/.年]", " ".join(text_blocks))


def test_review_schedule_chart_uses_theme_resources_and_scales_inside_clip() -> None:
    root = ET.parse(VIEW).getroot()
    xml = VIEW.read_text(encoding="utf-8")
    names = {node.tag.rsplit("}", 1)[-1] for node in root.iter()}

    assert "Viewbox" in names
    assert "ClipToBounds=\"True\"" in xml or "ClipToBounds=\"true\"" in xml
    assert "{DynamicResource AaosPrimaryBrush}" in xml
    assert "{DynamicResource AaosBorderBrush}" in xml


def test_review_schedule_chart_automation_name_states_no_review_history_data() -> None:
    root = ET.parse(VIEW).getroot()
    name = root.get("AutomationProperties.Name", "")
    code = CODE.read_text(encoding="utf-8")

    assert "无数据" in name
    assert "AaosReviewScheduleChart" in code
