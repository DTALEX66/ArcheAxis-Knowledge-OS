from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN_VIEW = ROOT / "apps" / "ArcheAxis.Desktop" / "MainWindow.axaml"


def test_search_b05_first_fold_is_query_then_full_width_results_table() -> None:
    root = ET.parse(MAIN_VIEW).getroot()
    xname = "{http://schemas.microsoft.com/winfx/2006/xaml}Name"
    names = {element.get(xname): element for element in root.iter() if element.get(xname)}
    search = names["SearchSurface"]
    parents = {child: parent for parent in root.iter() for child in parent}

    def direct_child(element: ET.Element) -> ET.Element:
        while parents[element] is not search:
            element = parents[element]
        return element

    assert list(search).index(direct_child(names["SearchPageQueryGrid"])) < list(search).index(direct_child(names["SearchPageResultsList"]))
    assert "SearchPageSelectedDetailBorder" not in names
    filters = names["SearchPageFilters"]
    assert direct_child(filters) is direct_child(names["SearchPageResultsList"])
    header = names["SearchResultsHeaderGrid"]
    assert header.get("ColumnDefinitions") == "1.2*,0.7*,0.8*,1.2*,0.7*"


def test_search_filters_and_selected_data_remain_available_without_duplicate_detail_card() -> None:
    root = ET.parse(MAIN_VIEW).getroot()
    xname = "{http://schemas.microsoft.com/winfx/2006/xaml}Name"
    names = {element.get(xname): element for element in root.iter() if element.get(xname)}
    for name in ("SearchPageTypeFilter", "SearchPageActiveOnly"):
        assert name in names
    for name in ("SearchPageSourceFilter", "SearchPageTopicFilter", "SearchPageTimeFilter"):
        assert name in names and names[name].get("IsVisible") == "False"
    code = (ROOT / "apps" / "ArcheAxis.Desktop" / "MainWindow.axaml.cs").read_text(encoding="utf-8")
    assert "ProjectSelectedLibraryResult(selected);" in code
