from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN_VIEW = ROOT / "apps" / "ArcheAxis.Desktop" / "MainWindow.axaml"


def test_human_learning_master_starts_with_metrics_and_keeps_load_action_in_plan_card() -> None:
    root = ET.parse(MAIN_VIEW).getroot()
    xname = "{http://schemas.microsoft.com/winfx/2006/xaml}Name"
    nodes = {element.get(xname): element for element in root.iter() if element.get(xname)}
    learning = nodes["LearningSurface"]
    direct_named_children = [element.get(xname) for element in learning]
    assert direct_named_children.index("LearningMetricsGrid") < direct_named_children.index("LearningPlanGrid")
    assert "LoadLearningButton" not in direct_named_children
    plan = nodes["LearningPlanGrid"]
    assert nodes["LoadLearningButton"] in list(plan.iter())


def test_human_learning_empty_tracks_do_not_repeat_fake_topic_labels() -> None:
    root = ET.parse(MAIN_VIEW).getroot()
    xname = "{http://schemas.microsoft.com/winfx/2006/xaml}Name"
    nodes = {element.get(xname): element for element in root.iter() if element.get(xname)}
    rows = nodes["LearningPlanPlaceholderRows"]
    assert len([element for element in rows.iter() if "learning-plan-empty-track" in element.get("Classes", "")]) == 5
    assert all("未暴露学习主题" not in element.get("Text", "") for element in rows.iter())
    assert any("学习计划项与进度等待 Core 投影" in element.get("Text", "") for element in nodes["LearningPlanGrid"].iter())
