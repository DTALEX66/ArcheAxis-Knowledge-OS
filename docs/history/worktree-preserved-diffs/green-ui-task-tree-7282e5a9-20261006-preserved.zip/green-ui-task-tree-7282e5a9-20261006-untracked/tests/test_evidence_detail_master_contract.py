from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
XAML_PATH = ROOT / "apps" / "ArcheAxis.Desktop" / "Views" / "EvidenceCenterView.axaml"
CODE_PATH = ROOT / "apps" / "ArcheAxis.Desktop" / "Views" / "EvidenceCenterView.axaml.cs"


def test_evidence_detail_matches_b05_columns_and_seven_large_source_nodes():
    root = ET.parse(XAML_PATH).getroot()
    named = {element.get("{http://schemas.microsoft.com/winfx/2006/xaml}Name"): element for element in root.iter()}

    detail_grid = named["EvidenceDetailPageGrid"]
    assert detail_grid.get("ColumnDefinitions") == "1.1*,1*"

    illustration = named["EvidenceSourceChainIllustration"]
    nodes = [element for element in illustration if element.tag.endswith("Ellipse")]
    assert len(nodes) == 7
    assert all(node.get("Width") == "32" and node.get("Height") == "32" for node in nodes)


def test_evidence_detail_stacks_at_narrow_width_and_keeps_core_unknowns():
    code = CODE_PATH.read_text(encoding="utf-8")
    assert "var detailColumns = width < 1024 ? 1 : 2;" in code
    assert 'new ColumnDefinitions("1.1*,1*")' in code
    assert 'EvidenceVerifiedMetricText.Text = "—"' in code
    assert 'EvidenceReviewMetricText.Text = "—"' in code
    xaml = XAML_PATH.read_text(encoding="utf-8")
    assert 'Text="已验证 · 暂无数据"' in xaml
    assert 'Text="待复核 · 暂无数据"' in xaml
    assert "DataTemplate" in code and "using Avalonia.Controls.Templates;" in code


def test_evidence_empty_state_uses_l6_aurora_ring_and_preserves_truthful_actions():
    root = ET.parse(XAML_PATH).getroot()
    named = {element.get("{http://schemas.microsoft.com/winfx/2006/xaml}Name"): element for element in root.iter()}
    empty_state = named["EvidenceEmptyState"]
    assert not any(element.tag.endswith("Image") for element in empty_state.iter())
    artwork = named["EvidenceEmptyStateImage"]
    rings = [element for element in artwork.iter() if element.tag.endswith("Ellipse")]
    assert len(rings) == 1
    assert rings[0].get("Stroke") == "{DynamicResource AaosPrimaryBrush}"
    assert rings[0].get("Fill") in (None, "Transparent")
    assert 'Text="尚未读取 Evidence anchor"' in XAML_PATH.read_text(encoding="utf-8")
    assert 'Content="去捕获来源"' in XAML_PATH.read_text(encoding="utf-8")
    assert 'Content="查看任务回执"' in XAML_PATH.read_text(encoding="utf-8")
