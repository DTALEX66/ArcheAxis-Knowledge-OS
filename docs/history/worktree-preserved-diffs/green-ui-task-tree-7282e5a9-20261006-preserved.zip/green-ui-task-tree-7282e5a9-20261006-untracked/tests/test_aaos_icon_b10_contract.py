from pathlib import Path
import re

import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
ICON_CODE = ROOT / "apps" / "ArcheAxis.Desktop" / "AaosIcon.axaml.cs"
ICON_XAML = ROOT / "apps" / "ArcheAxis.Desktop" / "AaosIcon.axaml"
MAIN_XAML = ROOT / "apps" / "ArcheAxis.Desktop" / "MainWindow.axaml"
THEME_CODE = ROOT / "apps" / "ArcheAxis.Desktop" / "ThemePalette.cs"
B10_HTML = ROOT / ".project-local" / "inputs" / "AAOS" / "extracted" / "archeaxis_最终版_高保真可部署UI" / "index.html"
ICON_BOARD = ROOT / ".project-local" / "inputs" / "AAOS" / "extracted" / "ArcheAxis_VI_12张独立图" / "10_10_图标系统_Icon_System.png"


def test_navigation_dots_match_b10_and_core_mobile_icons_are_registered():
    b10 = B10_HTML.read_text(encoding="utf-8")
    assert re.search(r"\.nav-dot\s*\{[^}]*width\s*:\s*10px\s*;\s*height\s*:\s*10px\s*;\s*border-radius\s*:\s*50%\s*;\s*border\s*:\s*2px\s+solid\s+currentColor", b10, re.S)

    icon_xaml = ET.parse(ICON_XAML).getroot()
    shapes = {node.get("{http://schemas.microsoft.com/winfx/2006/xaml}Name"): node for node in icon_xaml.iter()}
    dot = shapes["NavigationDotShape"]
    assert dot.get("Width") == dot.get("Height") == "10"
    assert dot.get("StrokeThickness") == "2"
    assert dot.get("Fill") == "Transparent"

    code = ICON_CODE.read_text(encoding="utf-8")
    names = set(re.findall(r'^\s*\["([^"]+)"\]\s*=', code, re.M))
    assert {"Knowledge", "Evidence", "Search", "Memory", "Growth", "HumanAi", "Connection", "Thinking"} <= names
    main = MAIN_XAML.read_text(encoding="utf-8")
    for name in ("Knowledge", "Capture", "Evidence", "Review"):
        assert f'IconName="{name}"' in main


def test_icon_stroke_and_foreground_follow_both_theme_palettes():
    code = ICON_CODE.read_text(encoding="utf-8")
    xaml = ICON_XAML.read_text(encoding="utf-8")
    palettes = THEME_CODE.read_text(encoding="utf-8")
    assert "IconStrokeThickness => 1.7" in code
    assert 'Stroke="{Binding Foreground, RelativeSource={RelativeSource AncestorType=UserControl}}"' in xaml
    assert 'StrokeThickness="{Binding IconStrokeThickness' in xaml
    assert palettes.count('["AaosIvoryBrush"]') == 2
    assert "#F3EFE6" in palettes and "#F1F2F3" in palettes
    assert ICON_BOARD.is_file()
