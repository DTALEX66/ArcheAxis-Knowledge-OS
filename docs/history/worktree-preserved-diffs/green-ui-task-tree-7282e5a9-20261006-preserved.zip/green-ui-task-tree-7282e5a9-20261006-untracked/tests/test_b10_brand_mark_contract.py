from pathlib import Path
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[1]
XAML_PATH = ROOT / "apps" / "ArcheAxis.Desktop" / "AaosBrandMark.axaml"
CODE_PATH = ROOT / "apps" / "ArcheAxis.Desktop" / "AaosBrandMark.axaml.cs"


def test_brand_mark_recreates_b10_shape_and_uses_live_theme_brushes():
    xaml = XAML_PATH.read_text(encoding="utf-8")
    code = CODE_PATH.read_text(encoding="utf-8")
    root = ET.fromstring(xaml)

    assert root.attrib.get("Width") == "48"
    assert root.attrib.get("Height") == "48"
    assert 'CornerRadius="16"' in xaml
    assert 'Background="{DynamicResource AaosBrandMarkBrush}"' in xaml
    assert 'BorderBrush="{DynamicResource AaosPrimaryBrush}"' in xaml
    assert 'Background="{DynamicResource AaosPrimaryBrush}"' in xaml
    assert 'Text="AA"' in xaml
    assert 'Foreground="White"' in xaml
    assert 'FontWeight="Black"' in xaml
    assert "Bitmap" not in xaml
    assert "ThemePalette.PaletteChanged" in code
    assert 'ThemePalette.ResolveBrush("AaosPrimaryBrush")' in code
    assert "RadialGradientBrush" in code
    assert "GradientOrigin" in code


def test_brand_mark_highlight_is_centered_at_b10_thirty_thirty_and_fades_at_forty_five():
    code = CODE_PATH.read_text(encoding="utf-8")

    assert "0.3, 0.3" in code
    assert "0.45" in code
    assert "GradientStop" in code
    assert "Colors.White" in code
    assert "BlurEffect" in XAML_PATH.read_text(encoding="utf-8")
