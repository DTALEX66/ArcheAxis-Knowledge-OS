using System;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Threading;

namespace ArcheAxis.Desktop;

public sealed class MemoryGraphNodeSelectedEventArgs : EventArgs
{
    public string NodeName { get; }

    public MemoryGraphNodeSelectedEventArgs(string nodeName) => NodeName = nodeName;
}

public partial class AaosMemoryGraphView : UserControl
{
    private Button? _selectedNode;
    private readonly DispatcherTimer _pulseTimer = new() { Interval = TimeSpan.FromMilliseconds(1500) };
    private bool _reducedMotion;
    private bool _pulseDimmed;
    private bool _motionActive;

    public event EventHandler<MemoryGraphNodeSelectedEventArgs>? NodeSelected;

    public AaosMemoryGraphView()
    {
        InitializeComponent();
        _pulseTimer.Tick += OnPulseTick;
    }

    public void SetReducedMotion(bool reducedMotion)
    {
        _reducedMotion = reducedMotion;
        UpdatePulseState();
    }

    public void SetMotionActive(bool active)
    {
        _motionActive = active;
        UpdatePulseState();
    }

    private void UpdatePulseState()
    {
        if (_reducedMotion || !_motionActive || !IsVisible)
        {
            _pulseTimer.Stop();
            _pulseDimmed = false;
            CoreKnowledgeNode.Opacity = 1;
            return;
        }

        _pulseTimer.Start();
    }

    private void OnPulseTick(object? sender, EventArgs e)
    {
        _pulseDimmed = !_pulseDimmed;
        CoreKnowledgeNode.Opacity = _pulseDimmed ? 0.86 : 1;
    }

    private void OnNodeClick(object? sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string nodeName } selectedNode)
            return;

        _selectedNode?.Classes.Set("selected", false);
        _selectedNode = selectedNode;
        _selectedNode.Classes.Set("selected", true);
        NodeSelected?.Invoke(this, new MemoryGraphNodeSelectedEventArgs(nodeName));
    }
}
