using System;
using Avalonia;
using Avalonia.Automation;
using Avalonia.Controls;
using Avalonia.Controls.Shapes;
using Avalonia.Interactivity;
using Avalonia.Media;

namespace ArcheAxis.Desktop;

public partial class AaosMemoryMapConstellation : UserControl
{
    public const int MasterNodeCount = 14;

    private static readonly Point[] MasterNodeCenters =
    {
        new(450, 260), new(431, 177), new(368, 106), new(284, 49),
        new(196, 49), new(112, 106), new(49, 177), new(30, 260),
        new(49, 343), new(112, 414), new(196, 471), new(284, 471),
        new(368, 414), new(431, 343),
    };

    private Button? _selectedNode;

    public event EventHandler<MemoryGraphNodeSelectedEventArgs>? NodeSelected;

    public AaosMemoryMapConstellation()
    {
        InitializeComponent();
        BuildMasterConstellation();
        ThemePalette.PaletteChanged += OnThemePaletteChanged;
    }

    private void BuildMasterConstellation()
    {
        for (var index = 0; index < MasterNodeCenters.Length; index++)
        {
            var center = MasterNodeCenters[index];
            var line = new Line
            {
                StartPoint = new Point(260, 260),
                EndPoint = center,
                StrokeThickness = 1.2,
                Opacity = 0.76,
                IsHitTestVisible = false,
            };
            line.Stroke = ThemePalette.ResolveBrush("AaosBorderBrush");
            GraphCanvas.Children.Insert(0, line);

            var node = new Button
            {
                Width = 18,
                Height = 18,
                Padding = new Thickness(0),
                CornerRadius = new CornerRadius(9),
                BorderThickness = new Thickness(1.5),
                Background = Brushes.Transparent,
                Tag = index + 1,
                ZIndex = 1,
            };
            node.BorderBrush = ThemePalette.ResolveBrush("AaosGoldBrush");
            node.Background = ThemePalette.ResolveBrush("AaosSurface2Brush");
            AutomationProperties.SetName(node, $"选择示意节点 {index + 1}；不表示真实图谱关系");
            node.Click += OnNodeClick;
            Canvas.SetLeft(node, center.X - node.Width / 2);
            Canvas.SetTop(node, center.Y - node.Height / 2);
            GraphCanvas.Children.Add(node);
        }
    }

    private void OnThemePaletteChanged(object? sender, EventArgs e)
    {
        foreach (var child in GraphCanvas.Children)
        {
            if (child is Line line)
                line.Stroke = ThemePalette.ResolveBrush("AaosBorderBrush");
            else if (child is Button node)
            {
                node.BorderBrush = ThemePalette.ResolveBrush("AaosGoldBrush");
                if (node.Classes.Contains("selected"))
                    continue;
                node.Background = ThemePalette.ResolveBrush("AaosSurface2Brush");
            }
        }
    }

    private void OnNodeClick(object? sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: int nodeNumber } selectedNode)
            return;

        _selectedNode?.Classes.Set("selected", false);
        _selectedNode = selectedNode;
        _selectedNode.Classes.Set("selected", true);
        NodeSelected?.Invoke(this, new MemoryGraphNodeSelectedEventArgs($"示意节点 {nodeNumber}"));
    }
}
