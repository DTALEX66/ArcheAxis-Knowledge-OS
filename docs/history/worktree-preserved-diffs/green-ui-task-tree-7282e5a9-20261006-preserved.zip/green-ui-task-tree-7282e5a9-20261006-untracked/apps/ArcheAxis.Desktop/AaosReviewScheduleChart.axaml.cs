using Avalonia.Controls;

namespace ArcheAxis.Desktop;

public partial class AaosReviewScheduleChart : UserControl
{
    public AaosReviewScheduleChart()
    {
        InitializeComponent();
    }
}
