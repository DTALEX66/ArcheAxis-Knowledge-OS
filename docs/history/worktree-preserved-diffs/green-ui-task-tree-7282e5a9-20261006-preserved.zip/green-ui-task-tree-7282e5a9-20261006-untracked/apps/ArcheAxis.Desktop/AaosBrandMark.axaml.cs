using System;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.VisualTree;

namespace ArcheAxis.Desktop;

/// <summary>Responsive 48-DIP ArcheAxis mark, redrawn from the B10 brand-mark CSS.</summary>
public partial class AaosBrandMark : UserControl
{
    public AaosBrandMark()
    {
        InitializeComponent();
        RefreshHighlight();
    }

    protected override void OnAttachedToVisualTree(VisualTreeAttachmentEventArgs e)
    {
        base.OnAttachedToVisualTree(e);
        ThemePalette.PaletteChanged += OnPaletteChanged;
        RefreshHighlight();
    }

    protected override void OnDetachedFromVisualTree(VisualTreeAttachmentEventArgs e)
    {
        ThemePalette.PaletteChanged -= OnPaletteChanged;
        base.OnDetachedFromVisualTree(e);
    }

    private void OnPaletteChanged(object? sender, EventArgs e) => RefreshHighlight();

    private void RefreshHighlight()
    {
        if (HighlightLayer is null || ThemePalette.ResolveBrush("AaosPrimaryBrush") is not SolidColorBrush primary)
            return;

        var highlight = Mix(primary.Color, Colors.White, 0.06 / (0.80 + 0.06));
        var radial = new RadialGradientBrush
        {
            Center = new RelativePoint(0.3, 0.3, RelativeUnit.Relative),
            GradientOrigin = new RelativePoint(0.3, 0.3, RelativeUnit.Relative),
            RadiusX = new RelativeScalar(0.45, RelativeUnit.Relative),
            RadiusY = new RelativeScalar(0.45, RelativeUnit.Relative),
        };
        radial.GradientStops.Add(new GradientStop(highlight, 0));
        radial.GradientStops.Add(new GradientStop(Color.FromArgb(0, highlight.R, highlight.G, highlight.B), 1));
        HighlightLayer.Background = radial;
    }

    private static Color Mix(Color source, Color target, double targetWeight)
    {
        static byte Channel(byte left, byte right, double weight) =>
            (byte)Math.Clamp(Math.Round(left * (1 - weight) + right * weight), byte.MinValue, byte.MaxValue);

        return Color.FromArgb(
            source.A,
            Channel(source.R, target.R, targetWeight),
            Channel(source.G, target.G, targetWeight),
            Channel(source.B, target.B, targetWeight));
    }
}
