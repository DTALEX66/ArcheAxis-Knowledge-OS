using System;
using System.Collections.Generic;
using Avalonia.Controls;
using Avalonia.Media;

namespace ArcheAxis.Desktop;

/// <summary>Reusable AAOS line icon set, redrawn from the VI icon-system board.</summary>
public partial class AaosIcon : UserControl
{
    public double IconStrokeThickness => 1.7;
    private static readonly IReadOnlyDictionary<string, string> GeometryByName =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["NavigationDot"] = "M12,2 A10,10 0 1,1 12,22 A10,10 0 1,1 12,2 Z",
            ["Knowledge"] = "M2,4 C5,3 9,4 12,6 C15,4 19,3 22,4 L22,20 C18,18 15,19 12,21 C9,19 6,18 2,20 Z M12,6 L12,21",
            ["Evidence"] = "M5,2 L15,2 L20,7 L20,22 L5,22 Z M15,2 L15,7 L20,7 M8,12 L17,12 M8,16 L17,16",
            ["Search"] = "M18,10.5 A7.5,7.5 0 1,1 3,10.5 A7.5,7.5 0 1,1 18,10.5 M16,16 L22,22",
            ["Memory"] = "M3,6 C3,2 21,2 21,6 C21,10 3,10 3,6 Z M3,6 L3,18 C3,22 21,22 21,18 L21,6 M3,12 C3,16 21,16 21,12",
            ["Growth"] = "M3,21 L3,15 M8,21 L8,11 M13,21 L13,7 M18,21 L18,3 M2,21 L22,21",
            ["HumanAi"] = "M8,11 A4,4 0 1,1 8,3 A4,4 0 1,1 8,11 M1,21 C1,17 4,14 8,14 C12,14 15,17 15,21 M17,12 A3,3 0 1,0 17,6 M17,15 C20,15 22,17 22,20",
            ["Connection"] = "M12,4 L4,18 L20,18 Z M12,4 L12,14 M4,18 L12,14 M20,18 L12,14 M12,2 A2,2 0 1,1 12,6 A2,2 0 1,1 12,2 M2,18 A2,2 0 1,1 2,22 A2,2 0 1,1 2,18 M20,18 A2,2 0 1,1 20,22 A2,2 0 1,1 20,18",
            ["Thinking"] = "M8,16 C8,14 5,12 5,9 A7,7 0 1,1 19,9 C19,12 16,14 16,16 Z M8,19 L16,19 M9,22 L15,22 M12,6 L12,10 M10,8 L12,10 L14,8",
            ["Capture"] = "M3,7 L8,7 L10,4 L15,4 L17,7 L21,7 L21,21 L3,21 Z M12,10 A4,4 0 1,0 12,18 A4,4 0 1,0 12,10",
            ["Original"] = "M3,17.5 L15.8,4.7 A2.1,2.1 0 0,1 18.8,7.7 L6,20.5 L2.5,21 Z M13.8,6.7 L16.8,9.7",
            ["Workspace"] = "M3,4 L10,4 L10,10 L3,10 Z M14,4 L21,4 L21,10 L14,10 Z M3,14 L10,14 L10,20 L3,20 Z M14,14 L21,14 L21,20 L14,20 Z M10,7 L14,7 M6.5,10 L6.5,14 M17.5,10 L17.5,14 M10,17 L14,17",
            ["Review"] = "M5,3 L19,3 L21,6 L21,21 L3,21 L3,6 Z M8,3 L8,7 M16,3 L16,7 M3,10 L21,10 M7,15 L10,18 L16,13",
            ["Settings"] = "M12,2 L13.5,5.2 L17,4.5 L18,8 L21.5,9.5 L20,13 L21.5,16.5 L18,18 L17,21.5 L13.5,20 L12,22 L10.5,20 L7,21.5 L6,18 L2.5,16.5 L4,13 L2.5,9.5 L6,8 L7,4.5 L10.5,5.2 Z M12,9 A4,4 0 1,0 12,17 A4,4 0 1,0 12,9",
            ["Notifications"] = "M18,9 A6,6 0 0,0 6,9 C6,16 3,16 3,18 L21,18 C21,16 18,16 18,9 M10,21 L14,21",
        };

    private string _iconName = "Knowledge";

    public string IconName
    {
        get => _iconName;
        set
        {
            if (!GeometryByName.TryGetValue(value, out var geometry))
                throw new ArgumentOutOfRangeException(nameof(value), value, "Unknown AAOS icon name.");

            _iconName = value;
            var isNavigationDot = string.Equals(value, "NavigationDot", StringComparison.OrdinalIgnoreCase);
            Classes.Set("navigation-dot", isNavigationDot);
            if (IconPath is not null)
            {
                IconPath.Data = Geometry.Parse(geometry);
                IconPath.IsVisible = !isNavigationDot;
                NavigationDotShape.IsVisible = isNavigationDot;
            }
        }
    }

    public AaosIcon()
    {
        InitializeComponent();
        IconPath.Data = Geometry.Parse(GeometryByName[_iconName]);
    }
}
