"""Illustrative development-only mount snippet.

Do not run this file directly. Apply manually on a feature branch after the standalone
MCS package passes its tests.
"""
from archeaxis_mcs.api import create_app as create_mcs_app

mcs_app = create_mcs_app(data_dir="data/mcs-phase5", embedded_worker=True)
# app.mount("/mcs", mcs_app)
