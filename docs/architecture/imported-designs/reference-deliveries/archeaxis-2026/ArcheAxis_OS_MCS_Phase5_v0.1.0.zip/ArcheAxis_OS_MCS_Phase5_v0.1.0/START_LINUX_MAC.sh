#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt
echo "[ArcheAxis] http://127.0.0.1:8010/"
exec .venv/bin/python -m archeaxis_mcs.server
