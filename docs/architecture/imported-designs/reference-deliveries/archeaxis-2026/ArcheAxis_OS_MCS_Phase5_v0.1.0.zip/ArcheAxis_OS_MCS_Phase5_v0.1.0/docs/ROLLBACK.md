# 回滚说明

本包默认使用独立数据库 `data/mcs.sqlite`，不会修改 Cognitive-Loop-OS 上游数据库。

## 数据重置

```bash
python -m archeaxis_mcs.cli reset
```

## 完全回滚

1. 停止 FastAPI/Worker；
2. 删除本交付包目录；
3. 若曾手工挂载到主仓库，删除挂载代码和复制进去的 `archeaxis_mcs/`；
4. 不需要迁移或恢复上游数据库。

禁止在服务运行时直接覆盖 SQLite 文件。
