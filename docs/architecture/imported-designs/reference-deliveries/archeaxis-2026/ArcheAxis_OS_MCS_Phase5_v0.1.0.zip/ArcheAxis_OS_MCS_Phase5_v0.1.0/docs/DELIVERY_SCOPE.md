# 交付范围与状态声明

## Available

- 本地可运行 FastAPI；
- 可视化闭环工作台；
- Research Review Gate；
- KnowledgeVersion 生成；
- LearningArtifact 审核；
- 5 项确定性练习；
- MasterySignal；
- MachineKnowledge Candidate 与审核；
- Audit / Job / Outbox / Idempotency；
- Google Research / 500 AI 治理种子；
- Provider dry-run 状态面板。

## Preview

- 从主仓库公共 Facade 导入 Phase 4 ResearchPackage；
- 将本包挂载到现有主网关。

## Roadmap / 不在本包

- 完整 React/TypeScript 主工作台；
- ContextPackV1 与通用 TaskPack 执行；
- Dynamic Planner；
- 通用多 Agent；
- 统一 Sleep Loop；
- 完整可视化教学编辑器；
- 2D/2.5D/3D 记忆宫殿；
- Desktop/Mobile/Relay；
- 企业多租户。
