# Phase 5 MCS 架构

```text
Browser Visual Workspace
        │ REST
        ▼
FastAPI /api/v1
        │
        ├── Command + Idempotency
        ├── Review Gate
        ├── Deterministic Practice Evaluator
        └── Query Projection
        │
        ▼
SQLite
├── immutable facts: review_decisions / practice_runs / audit_events
├── mutable work objects: research_packages / learning_artifacts / machine_knowledge_units
├── derived state: mastery_signals
├── transactional outbox: outbox_events
└── recoverable jobs: jobs
        │
        ▼
Outbox Worker
├── ResearchPackageReviewed → KnowledgeVersion + LearningArtifact Candidate
└── MasteryAchieved → MachineKnowledge Candidate
```

## 与 V3.1 的对应

- 不可静默修改事实：审核决定、练习证据、审计事件只追加；
- 可持续修改工作对象：使用 `revision` 和 `expected_revision`；
- 可重建视图：Dashboard 统计每次从事实表查询；
- 幂等：关键 Command 使用 `idempotency_key`；
- 事件一致性：业务写入和 Outbox 同一事务；
- Worker 恢复语义：事件状态、尝试次数、Job 状态和错误都持久化；
- 模型治理：仅本地确定性验证器为 Supported，云路由是 Candidate/Planned；
- 搜索/3D/同步不在本切片范围内。
