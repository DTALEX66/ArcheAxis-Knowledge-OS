# 测试报告

日期：2026-07-20  
交付版本：v0.1.0

## 自动测试

```text
python -m pytest -q
2 passed
```

覆盖：

- Phase 5 完整纵向闭环；
- 研究候选人工审核门禁；
- Outbox/Worker 派生正式知识与学习资产；
- 学习资产审核门禁；
- 3 次确定性练习与 MasterySignal；
- Mastery 后生成 MachineKnowledge Candidate；
- 机器知识二次人工审核；
- 关键命令幂等，重复提交不产生重复事件。

## Smoke Test

```text
PASS: Research → Review → Knowledge → Learning → Mastery → Machine Knowledge
{'research_packages': 1, 'active_knowledge': 1, 'learning_artifacts': 1, 'practice_runs': 3, 'machine_knowledge': 1, 'pending_events': 0}
```

## 运行验证

- FastAPI 启动成功；
- `/api/v1/system/health` 返回 200；
- `/` 工作台返回 200；
- 演示种子写入成功；
- 前端 JavaScript 通过 `node --check`；
- 交付 Manifest SHA-256 校验通过。

## 未验证项

- Windows 真实机器上的 Python 安装环境差异；
- 与主仓库同进程挂载后的全部回归测试；
- 云模型 Provider 在线调用（本包设计为不调用）；
- 多用户并发和跨设备同步。
