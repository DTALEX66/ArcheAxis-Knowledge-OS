# 验收清单

- [ ] Windows 一键启动成功，工作台可访问。
- [ ] `/api/v1/system/health` 返回 `ok`。
- [ ] 演示研究包初始状态是 `candidate`，且 `requires_human_review=true`。
- [ ] 未审核研究包时不存在正式知识。
- [ ] 批准研究后，Outbox 与 Job 产生记录。
- [ ] Worker 创建 `active` KnowledgeVersion 和 `candidate` LearningArtifact。
- [ ] 未批准学习资产时不能提交练习。
- [ ] 练习由 5 个确定性规则评分，不调用 Judge 模型。
- [ ] 3 次合格练习后 MasterySignal 为 `mastered`。
- [ ] Mastery 后才生成 MachineKnowledge Candidate。
- [ ] MachineKnowledge 未经审核不能为 `approved`。
- [ ] 幂等键重复提交不会重复产生事件或事实。
- [ ] 审计时间线能反向说明对象从哪里来、谁审核、如何派生。
- [ ] `python -m pytest -q` 通过。
- [ ] `python scripts/smoke_test.py` 通过。
- [ ] 删除本目录即可完全回滚，不影响主仓库。
