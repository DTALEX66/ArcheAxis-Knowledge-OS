from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field


class ReviewCommand(BaseModel):
    decision: Literal["approve", "reject", "request_changes"]
    reason: str = Field(min_length=3, max_length=1000)
    actor_id: str = Field(default="owner", min_length=1)
    idempotency_key: str = Field(min_length=8, max_length=200)
    expected_revision: int = Field(ge=1)


class PracticeCommand(BaseModel):
    response_text: str = Field(min_length=1, max_length=4000)
    actor_id: str = Field(default="learner", min_length=1)
    idempotency_key: str = Field(min_length=8, max_length=200)


class SeedCommand(BaseModel):
    force_reset: bool = False


class ImportResearchCommand(BaseModel):
    package_id: str
    title: str
    summary: str
    source_locator: str
    source_revision: str = "unknown"
    evidence: list[dict] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    unknowns: list[str] = Field(default_factory=list)
    independent_source_count: int = Field(default=1, ge=0)
