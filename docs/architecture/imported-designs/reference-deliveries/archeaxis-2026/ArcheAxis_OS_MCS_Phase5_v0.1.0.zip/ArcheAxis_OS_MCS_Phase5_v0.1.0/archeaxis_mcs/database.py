from __future__ import annotations

import contextlib
import sqlite3
from pathlib import Path
from typing import Iterator

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS research_packages (
    package_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    source_locator TEXT NOT NULL,
    source_revision TEXT NOT NULL,
    status TEXT NOT NULL,
    verification_status TEXT NOT NULL,
    provenance_status TEXT NOT NULL,
    risk_level TEXT NOT NULL,
    independent_source_count INTEGER NOT NULL,
    evidence_json TEXT NOT NULL,
    unknowns_json TEXT NOT NULL,
    risks_json TEXT NOT NULL,
    requires_human_review INTEGER NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    content_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS review_decisions (
    review_id TEXT PRIMARY KEY,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    decision TEXT NOT NULL,
    reason TEXT NOT NULL,
    actor_id TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS knowledge_versions (
    knowledge_version_id TEXT PRIMARY KEY,
    knowledge_id TEXT NOT NULL,
    version_num INTEGER NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    source_package_id TEXT NOT NULL,
    status TEXT NOT NULL,
    provenance_status TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    UNIQUE(knowledge_id, version_num),
    FOREIGN KEY(source_package_id) REFERENCES research_packages(package_id)
);

CREATE TABLE IF NOT EXISTS learning_artifacts (
    artifact_id TEXT PRIMARY KEY,
    knowledge_version_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    title TEXT NOT NULL,
    prompt TEXT NOT NULL,
    rubric_json TEXT NOT NULL,
    status TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(knowledge_version_id) REFERENCES knowledge_versions(knowledge_version_id)
);

CREATE TABLE IF NOT EXISTS practice_runs (
    practice_run_id TEXT PRIMARY KEY,
    artifact_id TEXT NOT NULL,
    response_text TEXT NOT NULL,
    checks_json TEXT NOT NULL,
    score INTEGER NOT NULL,
    passed INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(artifact_id) REFERENCES learning_artifacts(artifact_id)
);

CREATE TABLE IF NOT EXISTS mastery_signals (
    mastery_id TEXT PRIMARY KEY,
    artifact_id TEXT NOT NULL UNIQUE,
    review_count INTEGER NOT NULL,
    latest_quality INTEGER,
    unresolved_mistakes_json TEXT NOT NULL,
    is_mastered INTEGER NOT NULL,
    review_status TEXT NOT NULL,
    derived_from_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(artifact_id) REFERENCES learning_artifacts(artifact_id)
);

CREATE TABLE IF NOT EXISTS machine_knowledge_units (
    unit_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    source_knowledge_version_id TEXT NOT NULL,
    source_mastery_id TEXT NOT NULL,
    lifecycle_status TEXT NOT NULL,
    provenance_status TEXT NOT NULL,
    confidence REAL NOT NULL,
    allowed_tasks_json TEXT NOT NULL,
    blocked_tasks_json TEXT NOT NULL,
    requires_human_review INTEGER NOT NULL,
    revision INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY(source_knowledge_version_id) REFERENCES knowledge_versions(knowledge_version_id),
    FOREIGN KEY(source_mastery_id) REFERENCES mastery_signals(mastery_id)
);

CREATE TABLE IF NOT EXISTS registry_assets (
    asset_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    repository_url TEXT,
    pinned_revision TEXT,
    category TEXT NOT NULL,
    target_module TEXT NOT NULL,
    absorption_mode TEXT NOT NULL,
    status TEXT NOT NULL,
    risk_policy TEXT NOT NULL,
    requires_human_review INTEGER NOT NULL,
    note TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS provider_routes (
    provider_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    status TEXT NOT NULL,
    local_execution_possible INTEGER NOT NULL,
    requires_human_review INTEGER NOT NULL,
    notes TEXT NOT NULL,
    PRIMARY KEY(provider_id, model_id)
);

CREATE TABLE IF NOT EXISTS jobs (
    job_id TEXT PRIMARY KEY,
    job_type TEXT NOT NULL,
    status TEXT NOT NULL,
    input_reference TEXT NOT NULL,
    current_step TEXT NOT NULL,
    progress INTEGER NOT NULL,
    result_reference TEXT,
    error TEXT,
    created_at TEXT NOT NULL,
    started_at TEXT,
    finished_at TEXT
);

CREATE TABLE IF NOT EXISTS outbox_events (
    event_id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    aggregate_id TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    status TEXT NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    processed_at TEXT,
    error TEXT
);

CREATE TABLE IF NOT EXISTS audit_events (
    audit_id TEXT PRIMARY KEY,
    event_type TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    actor_id TEXT NOT NULL,
    detail_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS commands (
    idempotency_key TEXT PRIMARY KEY,
    command_type TEXT NOT NULL,
    result_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_review_object ON review_decisions(object_type, object_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox_events(status, created_at);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, created_at);
"""


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 30000")
        return conn

    def initialize(self) -> None:
        with self.connect() as conn:
            conn.executescript(SCHEMA)

    @contextlib.contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        conn = self.connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def reset(self) -> None:
        tables = [
            "commands", "audit_events", "outbox_events", "jobs", "provider_routes",
            "registry_assets", "machine_knowledge_units", "mastery_signals",
            "practice_runs", "learning_artifacts", "knowledge_versions",
            "review_decisions", "research_packages",
        ]
        with self.transaction() as conn:
            conn.execute("PRAGMA foreign_keys = OFF")
            for table in tables:
                conn.execute(f"DELETE FROM {table}")
            conn.execute("PRAGMA foreign_keys = ON")
