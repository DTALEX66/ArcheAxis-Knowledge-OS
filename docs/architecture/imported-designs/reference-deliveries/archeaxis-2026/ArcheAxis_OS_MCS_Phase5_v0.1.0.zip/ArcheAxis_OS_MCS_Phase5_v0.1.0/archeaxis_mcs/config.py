from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    package_root: Path
    data_dir: Path
    db_path: Path
    host: str = "127.0.0.1"
    port: int = 8010
    embedded_worker: bool = True


def load_settings(data_dir: str | Path | None = None) -> Settings:
    package_root = Path(__file__).resolve().parents[1]
    chosen = Path(data_dir) if data_dir else Path(
        os.environ.get("ARCHEAXIS_MCS_DATA_DIR", package_root / "data")
    )
    chosen = chosen.resolve()
    chosen.mkdir(parents=True, exist_ok=True)
    return Settings(
        package_root=package_root,
        data_dir=chosen,
        db_path=chosen / "mcs.sqlite",
        host=os.environ.get("ARCHEAXIS_MCS_HOST", "127.0.0.1"),
        port=int(os.environ.get("ARCHEAXIS_MCS_PORT", "8010")),
        embedded_worker=os.environ.get("ARCHEAXIS_MCS_EMBEDDED_WORKER", "true").lower()
        not in {"0", "false", "no"},
    )
