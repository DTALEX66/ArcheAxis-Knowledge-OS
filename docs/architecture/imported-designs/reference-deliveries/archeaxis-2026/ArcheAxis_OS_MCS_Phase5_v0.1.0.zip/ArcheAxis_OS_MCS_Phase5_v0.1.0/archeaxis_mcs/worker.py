from __future__ import annotations

import json
import threading
import time

from .database import Database
from .service import MCSService, dumps, new_id, utcnow


class OutboxWorker:
    def __init__(self, db: Database, poll_interval: float = 0.35):
        self.db = db
        self.service = MCSService(db)
        self.poll_interval = poll_interval
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.run_forever, name="archeaxis-mcs-worker", daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2)

    def run_forever(self) -> None:
        while not self.stop_event.is_set():
            handled = self.process_one()
            if not handled:
                self.stop_event.wait(self.poll_interval)

    def process_all(self, max_events: int = 100) -> int:
        count = 0
        while count < max_events and self.process_one():
            count += 1
        return count

    def process_one(self) -> bool:
        with self.db.transaction() as conn:
            event = conn.execute(
                "SELECT * FROM outbox_events WHERE status='pending' ORDER BY created_at LIMIT 1"
            ).fetchone()
            if not event:
                return False
            conn.execute(
                "UPDATE outbox_events SET status='processing',attempts=attempts+1 WHERE event_id=?",
                (event["event_id"],),
            )
            job_id = new_id("job")
            conn.execute(
                "INSERT INTO jobs(job_id,job_type,status,input_reference,current_step,progress,created_at,started_at) VALUES(?,?,?,?,?,?,?,?)",
                (job_id, event["event_type"], "running", event["aggregate_id"], "dispatch", 10, utcnow(), utcnow()),
            )

        try:
            if event["event_type"] == "ResearchPackageReviewed":
                result_ref = self._on_research_reviewed(event["aggregate_id"], job_id)
            elif event["event_type"] == "MasteryAchieved":
                result_ref = self._on_mastery_achieved(event["aggregate_id"], job_id)
            else:
                result_ref = event["aggregate_id"]
            with self.db.transaction() as conn:
                now = utcnow()
                conn.execute("UPDATE outbox_events SET status='processed',processed_at=? WHERE event_id=?", (now, event["event_id"]))
                conn.execute("UPDATE jobs SET status='succeeded',current_step='complete',progress=100,result_reference=?,finished_at=? WHERE job_id=?", (result_ref, now, job_id))
            return True
        except Exception as exc:
            with self.db.transaction() as conn:
                now = utcnow()
                conn.execute("UPDATE outbox_events SET status='failed',error=? WHERE event_id=?", (str(exc)[:1000], event["event_id"]))
                conn.execute("UPDATE jobs SET status='failed',error=?,finished_at=? WHERE job_id=?", (str(exc)[:1000], now, job_id))
            return True

    def _on_research_reviewed(self, package_id: str, job_id: str) -> str:
        with self.db.transaction() as conn:
            package = conn.execute("SELECT * FROM research_packages WHERE package_id=?", (package_id,)).fetchone()
            if not package or package["status"] != "verified":
                raise RuntimeError("research package is not verified")
            existing = conn.execute("SELECT knowledge_version_id FROM knowledge_versions WHERE source_package_id=?", (package_id,)).fetchone()
            if existing:
                return existing[0]
            now = utcnow()
            knowledge_id = "knowledge_instruction_constraints"
            version_id = new_id("kv")
            content = (
                "正式知识：复杂自然语言指令应拆分为独立、确定、可解释、可重复执行的约束。"
                "确定性验证器优先于不透明 Judge；模型判断只能作为候选证据。"
            )
            conn.execute(
                "INSERT INTO knowledge_versions VALUES(?,?,?,?,?,?,?,?,?,?)",
                (version_id, knowledge_id, 1, "确定性指令约束验证", content, package_id, "active", "server_verified", 1, now),
            )
            artifact_id = new_id("learning")
            rubric = [
                {"id": "contains_archeaxis", "label": "包含“元枢”"},
                {"id": "exactly_three_bullets", "label": "恰好 3 条“- ”步骤"},
                {"id": "max_240_chars", "label": "不超过 240 字"},
                {"id": "review_required", "label": "包含 review_required=true"},
                {"id": "forbidden_publish", "label": "不得出现“自动发布”"},
            ]
            prompt = "写一段元枢执行说明：不超过240字；恰好3条以“- ”开头的步骤；包含 review_required=true；不得出现禁用词。"
            conn.execute(
                "INSERT INTO learning_artifacts VALUES(?,?,?,?,?,?,?,?,?,?)",
                (artifact_id, version_id, "instruction_constraint_practice", "5 项确定性约束练习", prompt, dumps(rubric), "candidate", 1, now, now),
            )
            self.service._audit(conn, "KnowledgeVersionActivated", "knowledge_version", version_id, "system_worker", {"source_package_id": package_id})
            self.service._audit(conn, "LearningArtifactCreated", "learning_artifact", artifact_id, "system_worker", {"knowledge_version_id": version_id})
            conn.execute("UPDATE jobs SET current_step='knowledge_and_learning_created',progress=85 WHERE job_id=?", (job_id,))
            return version_id

    def _on_mastery_achieved(self, mastery_id: str, job_id: str) -> str:
        with self.db.transaction() as conn:
            mastery = conn.execute("SELECT * FROM mastery_signals WHERE mastery_id=?", (mastery_id,)).fetchone()
            if not mastery or not mastery["is_mastered"]:
                raise RuntimeError("mastery signal is not mastered")
            artifact = conn.execute("SELECT * FROM learning_artifacts WHERE artifact_id=?", (mastery["artifact_id"],)).fetchone()
            knowledge = conn.execute("SELECT * FROM knowledge_versions WHERE knowledge_version_id=?", (artifact["knowledge_version_id"],)).fetchone()
            existing = conn.execute("SELECT unit_id FROM machine_knowledge_units WHERE source_mastery_id=?", (mastery_id,)).fetchone()
            if existing:
                return existing[0]
            now = utcnow()
            unit_id = new_id("mku")
            content = (
                "机器知识候选：在执行用户指令前，先编译为独立约束并优先使用确定性验证器。"
                "若约束不可验证或证据不足，必须进入人工审核，不得自动发布。"
            )
            conn.execute(
                "INSERT INTO machine_knowledge_units VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    unit_id, "Instruction Constraint Verification Pattern", content,
                    knowledge["knowledge_version_id"], mastery_id, "candidate", "caller_supplied",
                    0.86, dumps(["validate_instruction", "evaluate_practice"]),
                    dumps(["auto_publish", "modify_formal_knowledge", "execute_third_party_code"]),
                    1, 1, now, now,
                ),
            )
            self.service._audit(conn, "MachineKnowledgeCandidateCreated", "machine_knowledge", unit_id, "system_worker", {"mastery_id": mastery_id})
            conn.execute("UPDATE jobs SET current_step='machine_candidate_created',progress=85 WHERE job_id=?", (job_id,))
            return unit_id


def main() -> None:
    from .config import load_settings
    settings = load_settings()
    worker = OutboxWorker(Database(settings.db_path))
    print(f"ArcheAxis worker: {settings.db_path}")
    try:
        worker.run_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
