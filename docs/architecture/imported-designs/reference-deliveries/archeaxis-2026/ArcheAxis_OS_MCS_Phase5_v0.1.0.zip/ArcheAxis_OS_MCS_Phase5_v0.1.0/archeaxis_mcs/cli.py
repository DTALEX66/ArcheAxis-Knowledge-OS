from __future__ import annotations

import argparse

from .config import load_settings
from .database import Database
from .service import MCSService
from .worker import OutboxWorker


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["seed", "reset", "drain"])
    args = parser.parse_args()
    settings = load_settings()
    db = Database(settings.db_path)
    service = MCSService(db)
    if args.command == "seed":
        print(service.seed_demo(False))
    elif args.command == "reset":
        db.reset()
        print(service.seed_demo(False))
    else:
        print({"processed": OutboxWorker(db).process_all()})


if __name__ == "__main__":
    main()
