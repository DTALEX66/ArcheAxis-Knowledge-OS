from __future__ import annotations

import contextlib
import uuid
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import load_settings
from .database import Database
from .models import ImportResearchCommand, PracticeCommand, ReviewCommand, SeedCommand
from .service import DomainError, MCSService
from .worker import OutboxWorker


def create_app(data_dir: str | Path | None = None, *, embedded_worker: bool | None = None) -> FastAPI:
    settings = load_settings(data_dir)
    db = Database(settings.db_path)
    service = MCSService(db)
    worker = OutboxWorker(db)
    use_worker = settings.embedded_worker if embedded_worker is None else embedded_worker

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        if use_worker:
            worker.start()
        yield
        worker.stop()

    app = FastAPI(
        title="ArcheAxis OS Phase 5 MCS",
        version="0.1.0",
        description="Research → Review → Knowledge → Learning → Mastery → Machine Knowledge",
        lifespan=lifespan,
    )
    app.state.db = db
    app.state.service = service
    app.state.worker = worker

    static_dir = Path(__file__).resolve().parent / "static"
    app.mount("/assets", StaticFiles(directory=static_dir), name="assets")

    @app.middleware("http")
    async def trace_middleware(request: Request, call_next):
        trace_id = request.headers.get("X-Trace-ID") or f"trace_{uuid.uuid4().hex[:16]}"
        request.state.trace_id = trace_id
        response = await call_next(request)
        response.headers["X-Trace-ID"] = trace_id
        return response

    @app.exception_handler(DomainError)
    async def domain_error_handler(request: Request, exc: DomainError):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error": {
                    "code": exc.code,
                    "message": exc.message,
                    "details": exc.details,
                    "retryable": exc.status_code >= 500,
                    "remediation": exc.remediation,
                    "trace_id": request.state.trace_id,
                }
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_error_handler(request: Request, exc: Exception):
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "系统内部错误",
                    "details": {"type": type(exc).__name__},
                    "retryable": False,
                    "remediation": "查看终端日志和审计事件",
                    "trace_id": request.state.trace_id,
                }
            },
        )

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(static_dir / "index.html")

    @app.get("/api/v1/system/health")
    def health():
        return {
            "status": "ok",
            "system": "archeaxis-os-mcs-phase5",
            "version": "0.1.0",
            "database": str(settings.db_path),
            "embedded_worker": use_worker,
            "capabilities": [
                "research_review", "knowledge_version", "learning_review",
                "deterministic_practice", "mastery_signal", "machine_knowledge_review",
                "outbox", "jobs", "audit", "idempotency",
            ],
        }

    @app.get("/api/v1/dashboard")
    def dashboard():
        return service.dashboard()

    @app.post("/api/v1/demo/seed")
    def seed(command: SeedCommand):
        result = service.seed_demo(command.force_reset)
        if not use_worker:
            worker.process_all()
        return result

    @app.post("/api/v1/demo/reset")
    def reset():
        db.reset()
        return service.seed_demo(False)

    @app.post("/api/v1/research/import")
    def import_research(command: ImportResearchCommand):
        return service.import_research(command.model_dump())

    @app.get("/api/v1/research/packages")
    def research_packages():
        return service.list_rows("research_packages")

    @app.post("/api/v1/research/packages/{package_id}/reviews")
    def review_research(package_id: str, command: ReviewCommand):
        return service.review_research(package_id, command.model_dump())

    @app.get("/api/v1/knowledge/versions")
    def knowledge_versions():
        return service.list_rows("knowledge_versions")

    @app.get("/api/v1/learning/artifacts")
    def learning_artifacts():
        return service.list_rows("learning_artifacts")

    @app.post("/api/v1/learning/artifacts/{artifact_id}/reviews")
    def review_learning(artifact_id: str, command: ReviewCommand):
        return service.review_learning(artifact_id, command.model_dump())

    @app.post("/api/v1/learning/artifacts/{artifact_id}/practice")
    def practice(artifact_id: str, command: PracticeCommand):
        return service.practice(artifact_id, command.model_dump())

    @app.get("/api/v1/learning/practice-runs")
    def practice_runs():
        return service.list_rows("practice_runs")

    @app.get("/api/v1/learning/mastery-signals")
    def mastery_signals():
        return service.list_rows("mastery_signals", "updated_at DESC")

    @app.get("/api/v1/machine-knowledge/units")
    def machine_units():
        return service.list_rows("machine_knowledge_units")

    @app.post("/api/v1/machine-knowledge/units/{unit_id}/reviews")
    def review_machine(unit_id: str, command: ReviewCommand):
        return service.review_machine_knowledge(unit_id, command.model_dump())

    @app.get("/api/v1/foundry/providers")
    def provider_routes():
        return service.list_rows("provider_routes", "provider_id, model_id")

    @app.get("/api/v1/foundry/registry-assets")
    def registry_assets():
        return service.list_rows("registry_assets", "asset_id")

    @app.get("/api/v1/system/jobs")
    def jobs():
        return service.list_rows("jobs")

    @app.get("/api/v1/system/events")
    def events():
        return service.list_rows("outbox_events")

    @app.get("/api/v1/system/audit")
    def audit():
        return service.list_rows("audit_events")

    @app.post("/api/v1/system/worker/drain")
    def drain():
        return {"processed": worker.process_all()}

    return app
