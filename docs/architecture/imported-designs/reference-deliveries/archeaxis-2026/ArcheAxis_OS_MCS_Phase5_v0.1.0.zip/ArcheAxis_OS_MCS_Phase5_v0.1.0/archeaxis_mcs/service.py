from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from datetime import datetime, timezone
from typing import Any

from .database import Database


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:16]}"


def dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row else None


class DomainError(Exception):
    def __init__(self, code: str, message: str, *, status_code: int = 400, details=None, remediation=""):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        self.remediation = remediation


class MCSService:
    def __init__(self, db: Database):
        self.db = db

    def _audit(self, conn, event_type: str, object_type: str, object_id: str, actor_id: str, detail: dict):
        conn.execute(
            "INSERT INTO audit_events VALUES (?, ?, ?, ?, ?, ?, ?)",
            (new_id("audit"), event_type, object_type, object_id, actor_id, dumps(detail), utcnow()),
        )

    def _outbox(self, conn, event_type: str, aggregate_id: str, payload: dict) -> str:
        event_id = new_id("evt")
        conn.execute(
            "INSERT INTO outbox_events(event_id,event_type,aggregate_id,payload_json,status,created_at) VALUES(?,?,?,?,?,?)",
            (event_id, event_type, aggregate_id, dumps(payload), "pending", utcnow()),
        )
        return event_id

    def _command_result(self, conn, key: str) -> dict | None:
        row = conn.execute("SELECT result_json FROM commands WHERE idempotency_key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def _save_command(self, conn, key: str, command_type: str, result: dict) -> None:
        conn.execute(
            "INSERT INTO commands(idempotency_key,command_type,result_json,created_at) VALUES(?,?,?,?)",
            (key, command_type, dumps(result), utcnow()),
        )

    def seed_demo(self, force_reset: bool = False) -> dict:
        if force_reset:
            self.db.reset()
        with self.db.transaction() as conn:
            existing = conn.execute("SELECT package_id FROM research_packages LIMIT 1").fetchone()
            if existing:
                return {"status": "already_seeded", "package_id": existing[0]}

            assets = [
                (
                    "research_google_ifeval", "google-research/instruction_following_eval",
                    "https://github.com/google-research/google-research/tree/master/instruction_following_eval",
                    "pin-required", "research_subproject", "evaluation",
                    "research_only", "candidate", "must_review_before_use", 1,
                    "只吸收可验证指令约束方法；禁止整仓 vendor 和自动执行第三方代码。",
                ),
                (
                    "learning_500ai_index", "500 AI Projects resource index",
                    "https://github.com/ashishpatel26/500-AI-Machine-learning-Deep-learning-Computer-vision-NLP-Projects-with-code",
                    "pin-required", "learning_resource_index", "learning",
                    "参考/候选Adapter", "candidate", "must_review_before_use", 1,
                    "只做链接发现、类型化、去重和人工筛选；不得自动运行外部项目。",
                ),
            ]
            conn.executemany(
                "INSERT INTO registry_assets VALUES(?,?,?,?,?,?,?,?,?,?,?)", assets
            )

            routes = [
                (
                    "local", "deterministic-instruction-validator-v1", "evaluation", "supported",
                    1, 0, "本包唯一默认执行路线；纯本地、确定性、无模型调用。",
                ),
                (
                    "deepseek", "unbound", "llm", "candidate",
                    0, 1, "对齐仓库 ProviderContract；未配置、未在线验证、不会被本包调用。",
                ),
                (
                    "openai", "unbound", "llm", "planned",
                    0, 1, "能力占位，不构成可用路由。",
                ),
            ]
            conn.executemany("INSERT INTO provider_routes VALUES(?,?,?,?,?,?,?)", routes)

            package_id = "research_ifeval_mcs_001"
            now = utcnow()
            evidence = [
                {
                    "evidence_id": "evidence_ifeval_method_001",
                    "kind": "method_summary",
                    "context": "将自然语言指令拆分为可由确定性程序验证的约束。",
                    "source_locator": "google-research/instruction_following_eval",
                    "status": "unverified",
                },
                {
                    "evidence_id": "evidence_delivery_package_001",
                    "kind": "governed_delivery_decision",
                    "context": "首选 IFEval 建立 Research-to-Practice 最小闭环。",
                    "source_locator": "Cognitive_Loop_OS_GoogleResearch_500AI_Delivery_v1.0",
                    "status": "unverified",
                },
            ]
            summary = (
                "候选方法：把用户指令转成明确、可重复、可解释的确定性验证器，"
                "并将验证结果作为 Practice Evidence，而不是让 Judge 模型直接决定正确性。"
            )
            content_hash = hashlib.sha256((package_id + summary).encode("utf-8")).hexdigest()
            conn.execute(
                """INSERT INTO research_packages(
                    package_id,title,summary,source_locator,source_revision,status,
                    verification_status,provenance_status,risk_level,independent_source_count,
                    evidence_json,unknowns_json,risks_json,requires_human_review,revision,
                    content_hash,created_at,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    package_id, "IFEval：确定性指令约束验证方法", summary,
                    "https://github.com/google-research/google-research/tree/master/instruction_following_eval",
                    "pin-required", "candidate", "caller_supplied_candidate", "caller_supplied",
                    "medium", 1, dumps(evidence), dumps(["尚未固定上游 Commit SHA"]),
                    dumps(["外部方法不能直接成为 Active Knowledge", "不得执行未知第三方代码"]),
                    1, 1, content_hash, now, now,
                ),
            )
            self._audit(conn, "DemoSeeded", "research_package", package_id, "system", {"assets": 2})
            return {"status": "seeded", "package_id": package_id}

    def import_research(self, payload: dict) -> dict:
        package_id = payload["package_id"]
        with self.db.transaction() as conn:
            if conn.execute("SELECT 1 FROM research_packages WHERE package_id=?", (package_id,)).fetchone():
                raise DomainError("DUPLICATE_RESEARCH_PACKAGE", "研究包已存在", status_code=409)
            now = utcnow()
            digest = hashlib.sha256(dumps(payload).encode()).hexdigest()
            conn.execute(
                """INSERT INTO research_packages VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    package_id, payload["title"], payload["summary"], payload["source_locator"],
                    payload.get("source_revision", "unknown"), "candidate", "caller_supplied_candidate",
                    "caller_supplied", "medium", payload.get("independent_source_count", 1),
                    dumps(payload.get("evidence", [])), dumps(payload.get("unknowns", [])),
                    dumps(payload.get("risks", [])), 1, 1, digest, now, now,
                ),
            )
            self._audit(conn, "ResearchPackageImported", "research_package", package_id, "owner", {})
        return self.get_research(package_id)

    def list_rows(self, table: str, order_by: str = "created_at DESC") -> list[dict]:
        allowed = {
            "research_packages", "knowledge_versions", "learning_artifacts",
            "practice_runs", "mastery_signals", "machine_knowledge_units",
            "registry_assets", "provider_routes", "jobs", "outbox_events", "audit_events",
        }
        if table not in allowed:
            raise ValueError(table)
        with self.db.connect() as conn:
            rows = conn.execute(f"SELECT * FROM {table} ORDER BY {order_by}").fetchall()
        return [self._decode_row(dict(row)) for row in rows]

    def _decode_row(self, item: dict) -> dict:
        for key in list(item):
            if key.endswith("_json"):
                try:
                    item[key[:-5]] = json.loads(item[key])
                except Exception:
                    item[key[:-5]] = item[key]
                del item[key]
            if key in {"requires_human_review", "is_mastered", "passed", "local_execution_possible"}:
                item[key] = bool(item[key])
        return item

    def get_research(self, package_id: str) -> dict:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM research_packages WHERE package_id=?", (package_id,)).fetchone()
        if not row:
            raise DomainError("RESEARCH_NOT_FOUND", "研究包不存在", status_code=404)
        return self._decode_row(dict(row))

    def review_research(self, package_id: str, command: dict) -> dict:
        with self.db.transaction() as conn:
            replay = self._command_result(conn, command["idempotency_key"])
            if replay is not None:
                return {**replay, "idempotent_replay": True}
            row = conn.execute("SELECT * FROM research_packages WHERE package_id=?", (package_id,)).fetchone()
            if not row:
                raise DomainError("RESEARCH_NOT_FOUND", "研究包不存在", status_code=404)
            if row["revision"] != command["expected_revision"]:
                raise DomainError(
                    "VERSION_CONFLICT", "研究包版本冲突", status_code=409,
                    details={"expected_revision": command["expected_revision"], "current_revision": row["revision"]},
                    remediation="刷新对象后重新审核",
                )
            if row["status"] in {"verified", "rejected"}:
                raise DomainError("INVALID_STATE_TRANSITION", "该研究包已完成终态审核", status_code=409)
            decision = command["decision"]
            new_status = {"approve": "verified", "reject": "rejected", "request_changes": "candidate"}[decision]
            verification = "server_verified" if decision == "approve" else row["verification_status"]
            provenance = "server_verified" if decision == "approve" else row["provenance_status"]
            requires_review = 0 if decision in {"approve", "reject"} else 1
            now = utcnow()
            review_id = new_id("review")
            conn.execute(
                "INSERT INTO review_decisions VALUES(?,?,?,?,?,?,?)",
                (review_id, "research_package", package_id, decision, command["reason"], command["actor_id"], now),
            )
            conn.execute(
                """UPDATE research_packages SET status=?,verification_status=?,provenance_status=?,
                   requires_human_review=?,revision=revision+1,updated_at=? WHERE package_id=?""",
                (new_status, verification, provenance, requires_review, now, package_id),
            )
            event_id = None
            if decision == "approve":
                event_id = self._outbox(conn, "ResearchPackageReviewed", package_id, {"review_id": review_id})
            self._audit(conn, "ResearchPackageReviewed", "research_package", package_id, command["actor_id"], {"decision": decision, "review_id": review_id})
            result = {"package_id": package_id, "status": new_status, "review_id": review_id, "event_id": event_id}
            self._save_command(conn, command["idempotency_key"], "review_research", result)
            return result

    def review_learning(self, artifact_id: str, command: dict) -> dict:
        with self.db.transaction() as conn:
            replay = self._command_result(conn, command["idempotency_key"])
            if replay is not None:
                return {**replay, "idempotent_replay": True}
            row = conn.execute("SELECT * FROM learning_artifacts WHERE artifact_id=?", (artifact_id,)).fetchone()
            if not row:
                raise DomainError("LEARNING_ARTIFACT_NOT_FOUND", "学习资产不存在", status_code=404)
            if row["revision"] != command["expected_revision"]:
                raise DomainError("VERSION_CONFLICT", "学习资产版本冲突", status_code=409)
            if row["status"] in {"reviewed", "rejected"}:
                raise DomainError("INVALID_STATE_TRANSITION", "学习资产已完成审核", status_code=409)
            decision = command["decision"]
            new_status = {"approve": "reviewed", "reject": "rejected", "request_changes": "candidate"}[decision]
            review_id = new_id("review")
            now = utcnow()
            conn.execute("INSERT INTO review_decisions VALUES(?,?,?,?,?,?,?)", (review_id, "learning_artifact", artifact_id, decision, command["reason"], command["actor_id"], now))
            conn.execute("UPDATE learning_artifacts SET status=?,revision=revision+1,updated_at=? WHERE artifact_id=?", (new_status, now, artifact_id))
            self._audit(conn, "LearningArtifactReviewed", "learning_artifact", artifact_id, command["actor_id"], {"decision": decision})
            result = {"artifact_id": artifact_id, "status": new_status, "review_id": review_id}
            self._save_command(conn, command["idempotency_key"], "review_learning", result)
            return result

    @staticmethod
    def evaluate_instruction(response_text: str) -> tuple[list[dict], int]:
        lines = [line.rstrip() for line in response_text.strip().splitlines()]
        bullet_lines = [line for line in lines if line.startswith("- ")]
        checks = [
            {"id": "contains_archeaxis", "label": "包含“元枢”", "passed": "元枢" in response_text},
            {"id": "exactly_three_bullets", "label": "恰好 3 条“- ”步骤", "passed": len(bullet_lines) == 3},
            {"id": "max_240_chars", "label": "不超过 240 字", "passed": len(response_text) <= 240},
            {"id": "review_required", "label": "包含 review_required=true", "passed": "review_required=true" in response_text},
            {"id": "forbidden_publish", "label": "不得出现“自动发布”", "passed": "自动发布" not in response_text},
        ]
        score = sum(1 for item in checks if item["passed"])
        return checks, score

    def practice(self, artifact_id: str, command: dict) -> dict:
        with self.db.transaction() as conn:
            replay = self._command_result(conn, command["idempotency_key"])
            if replay is not None:
                return {**replay, "idempotent_replay": True}
            artifact = conn.execute("SELECT * FROM learning_artifacts WHERE artifact_id=?", (artifact_id,)).fetchone()
            if not artifact:
                raise DomainError("LEARNING_ARTIFACT_NOT_FOUND", "学习资产不存在", status_code=404)
            if artifact["status"] != "reviewed":
                raise DomainError(
                    "LEARNING_REVIEW_REQUIRED", "学习资产尚未通过审核", status_code=409,
                    remediation="先在学习资产审核区批准该资产",
                )
            checks, score = self.evaluate_instruction(command["response_text"])
            run_id = new_id("practice")
            now = utcnow()
            conn.execute(
                "INSERT INTO practice_runs VALUES(?,?,?,?,?,?,?)",
                (run_id, artifact_id, command["response_text"], dumps(checks), score, int(score == 5), now),
            )
            rows = conn.execute("SELECT practice_run_id,checks_json,score FROM practice_runs WHERE artifact_id=? ORDER BY created_at", (artifact_id,)).fetchall()
            unresolved = [item["id"] for item in checks if not item["passed"]]
            is_mastered = len(rows) >= 3 and score >= 4 and not unresolved
            status = "mastered" if is_mastered else ("struggling" if score < 4 else "reviewing")
            mastery = conn.execute("SELECT * FROM mastery_signals WHERE artifact_id=?", (artifact_id,)).fetchone()
            mastery_id = mastery["mastery_id"] if mastery else new_id("mastery")
            derived = [row["practice_run_id"] for row in rows]
            if mastery:
                was_mastered = bool(mastery["is_mastered"])
                conn.execute(
                    """UPDATE mastery_signals SET review_count=?,latest_quality=?,unresolved_mistakes_json=?,
                       is_mastered=?,review_status=?,derived_from_json=?,updated_at=? WHERE artifact_id=?""",
                    (len(rows), score, dumps(unresolved), int(is_mastered), status, dumps(derived), now, artifact_id),
                )
            else:
                was_mastered = False
                conn.execute(
                    "INSERT INTO mastery_signals VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (mastery_id, artifact_id, len(rows), score, dumps(unresolved), int(is_mastered), status, dumps(derived), now, now),
                )
            event_id = None
            if is_mastered and not was_mastered:
                event_id = self._outbox(conn, "MasteryAchieved", mastery_id, {"artifact_id": artifact_id})
            self._audit(conn, "PracticeEvaluated", "learning_artifact", artifact_id, command["actor_id"], {"run_id": run_id, "score": score, "mastered": is_mastered})
            result = {"practice_run_id": run_id, "score": score, "checks": checks, "mastery_id": mastery_id, "is_mastered": is_mastered, "event_id": event_id}
            self._save_command(conn, command["idempotency_key"], "practice", result)
            return result

    def review_machine_knowledge(self, unit_id: str, command: dict) -> dict:
        with self.db.transaction() as conn:
            replay = self._command_result(conn, command["idempotency_key"])
            if replay is not None:
                return {**replay, "idempotent_replay": True}
            row = conn.execute("SELECT * FROM machine_knowledge_units WHERE unit_id=?", (unit_id,)).fetchone()
            if not row:
                raise DomainError("MACHINE_KNOWLEDGE_NOT_FOUND", "机器知识不存在", status_code=404)
            if row["revision"] != command["expected_revision"]:
                raise DomainError("VERSION_CONFLICT", "机器知识版本冲突", status_code=409)
            if row["lifecycle_status"] in {"approved", "deprecated", "rejected"}:
                raise DomainError("INVALID_STATE_TRANSITION", "机器知识已完成终态审核", status_code=409)
            decision = command["decision"]
            new_status = {"approve": "approved", "reject": "rejected", "request_changes": "candidate"}[decision]
            provenance = "server_verified" if decision == "approve" else row["provenance_status"]
            requires_review = 0 if decision in {"approve", "reject"} else 1
            now = utcnow()
            review_id = new_id("review")
            conn.execute("INSERT INTO review_decisions VALUES(?,?,?,?,?,?,?)", (review_id, "machine_knowledge", unit_id, decision, command["reason"], command["actor_id"], now))
            conn.execute(
                """UPDATE machine_knowledge_units SET lifecycle_status=?,provenance_status=?,
                   requires_human_review=?,revision=revision+1,updated_at=? WHERE unit_id=?""",
                (new_status, provenance, requires_review, now, unit_id),
            )
            self._audit(conn, "MachineKnowledgeReviewed", "machine_knowledge", unit_id, command["actor_id"], {"decision": decision})
            result = {"unit_id": unit_id, "lifecycle_status": new_status, "review_id": review_id}
            self._save_command(conn, command["idempotency_key"], "review_machine_knowledge", result)
            return result

    def dashboard(self) -> dict:
        with self.db.connect() as conn:
            def count(table, where="1=1"):
                return conn.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}").fetchone()[0]
            research = conn.execute("SELECT status FROM research_packages ORDER BY created_at DESC LIMIT 1").fetchone()
            knowledge = conn.execute("SELECT status FROM knowledge_versions ORDER BY created_at DESC LIMIT 1").fetchone()
            learning = conn.execute("SELECT status FROM learning_artifacts ORDER BY created_at DESC LIMIT 1").fetchone()
            mastery = conn.execute("SELECT is_mastered,review_status,review_count FROM mastery_signals ORDER BY updated_at DESC LIMIT 1").fetchone()
            machine = conn.execute("SELECT lifecycle_status FROM machine_knowledge_units ORDER BY created_at DESC LIMIT 1").fetchone()
            recent = conn.execute("SELECT * FROM audit_events ORDER BY created_at DESC LIMIT 12").fetchall()
            jobs = conn.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT 8").fetchall()
            pending = count("outbox_events", "status='pending'")
        return {
            "metrics": {
                "research_packages": count_with(self.db, "research_packages"),
                "active_knowledge": count_with(self.db, "knowledge_versions", "status='active'"),
                "learning_artifacts": count_with(self.db, "learning_artifacts"),
                "practice_runs": count_with(self.db, "practice_runs"),
                "machine_knowledge": count_with(self.db, "machine_knowledge_units"),
                "pending_events": pending,
            },
            "pipeline": [
                {"key": "research", "label": "研究候选", "status": research[0] if research else "empty"},
                {"key": "knowledge", "label": "正式知识", "status": knowledge[0] if knowledge else "empty"},
                {"key": "learning", "label": "学习资产", "status": learning[0] if learning else "empty"},
                {"key": "mastery", "label": "掌握信号", "status": (mastery[1] if mastery else "empty"), "count": (mastery[2] if mastery else 0)},
                {"key": "machine", "label": "机器知识", "status": machine[0] if machine else "empty"},
            ],
            "recent_audit": [self._decode_row(dict(row)) for row in recent],
            "jobs": [self._decode_row(dict(row)) for row in jobs],
        }


def count_with(db: Database, table: str, where: str = "1=1") -> int:
    with db.connect() as conn:
        return conn.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}").fetchone()[0]
