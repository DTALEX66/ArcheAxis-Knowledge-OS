"""Optional read bridge for an existing Cognitive-Loop-OS checkout.

Run this module from the Cognitive-Loop-OS repository root. It intentionally imports
through the public facade and converts the Phase 4 candidate package into the Phase 5
MCS import contract. It never mutates the upstream repository database.
"""
from __future__ import annotations

from typing import Any


def read_upstream_research_package(package_id: str) -> dict[str, Any]:
    try:
        from app.facades.research import get_research_package
    except ImportError as exc:
        raise RuntimeError(
            "未找到 Cognitive-Loop-OS 公共 Facade。请从仓库根目录运行，或先安装主仓库。"
        ) from exc
    graph = get_research_package(package_id)
    package = graph.package.model_dump() if hasattr(graph.package, "model_dump") else dict(graph.package)
    claims = [item.model_dump() if hasattr(item, "model_dump") else dict(item) for item in graph.claims]
    evidence = [item.model_dump() if hasattr(item, "model_dump") else dict(item) for item in graph.evidence]
    return {
        "package_id": package["package_id"],
        "title": f"Imported Phase 4 package {package['package_id']}",
        "summary": "\n".join(item.get("statement", "") for item in claims)[:4000],
        "source_locator": package.get("source_record_ids", ["upstream"])[0],
        "source_revision": "upstream-facade",
        "evidence": evidence,
        "risks": package.get("risks", []),
        "unknowns": package.get("unknowns", []),
        "independent_source_count": package.get("independent_source_count", 0),
    }
