from __future__ import annotations

import uvicorn

from .api import create_app
from .config import load_settings


def main() -> None:
    settings = load_settings()
    uvicorn.run(
        create_app(settings.data_dir),
        host=settings.host,
        port=settings.port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
