from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from archeaxis_mcs.config import load_settings
from archeaxis_mcs.database import Database
from archeaxis_mcs.service import MCSService, utcnow


def main() -> None:
    settings=load_settings()
    service=MCSService(Database(settings.db_path))
    payload={
        'exported_at':utcnow(),
        'dashboard':service.dashboard(),
        'research':service.list_rows('research_packages'),
        'knowledge':service.list_rows('knowledge_versions'),
        'learning':service.list_rows('learning_artifacts'),
        'mastery':service.list_rows('mastery_signals','updated_at DESC'),
        'machine_knowledge':service.list_rows('machine_knowledge_units'),
        'jobs':service.list_rows('jobs'),
        'events':service.list_rows('outbox_events'),
        'audit':service.list_rows('audit_events'),
    }
    output=settings.data_dir/'mcs_audit_export.json'
    output.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(output)


if __name__=='__main__': main()
