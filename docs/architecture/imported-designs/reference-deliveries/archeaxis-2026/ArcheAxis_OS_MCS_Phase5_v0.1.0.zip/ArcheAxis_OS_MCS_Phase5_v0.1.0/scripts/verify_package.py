from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'delivery_manifest.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest['files']:
    path=ROOT/item['path']
    if not path.is_file(): errors.append(f"missing: {item['path']}"); continue
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    if digest!=item['sha256']: errors.append(f"hash mismatch: {item['path']}")
if errors:
    print('\n'.join(errors)); raise SystemExit(1)
print(f"PASS: {len(manifest['files'])} files verified")
