from __future__ import annotations

import shutil
import sys
import tempfile
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient
from archeaxis_mcs.api import create_app


def k(prefix): return f"{prefix}_{uuid.uuid4().hex}"


def main() -> None:
    temp = Path(tempfile.mkdtemp(prefix="archeaxis-mcs-smoke-"))
    try:
        with TestClient(create_app(temp, embedded_worker=False)) as client:
            assert client.get("/api/v1/system/health").status_code == 200
            client.post("/api/v1/demo/seed", json={"force_reset": False}).raise_for_status()
            research = client.get("/api/v1/research/packages").json()[0]
            client.post(f"/api/v1/research/packages/{research['package_id']}/reviews", json={
                "decision":"approve","reason":"smoke human review","actor_id":"smoke",
                "idempotency_key":k('research'),"expected_revision":research['revision']}).raise_for_status()
            client.post("/api/v1/system/worker/drain").raise_for_status()
            artifact = client.get("/api/v1/learning/artifacts").json()[0]
            client.post(f"/api/v1/learning/artifacts/{artifact['artifact_id']}/reviews", json={
                "decision":"approve","reason":"smoke learning review","actor_id":"smoke",
                "idempotency_key":k('learning'),"expected_revision":artifact['revision']}).raise_for_status()
            text='元枢执行说明：\n- 固定来源版本并保存证据\n- 运行确定性约束验证\n- review_required=true 后进入人工审核'
            for _ in range(3):
                response=client.post(f"/api/v1/learning/artifacts/{artifact['artifact_id']}/practice", json={"response_text":text,"actor_id":"smoke","idempotency_key":k('practice')})
                response.raise_for_status(); assert response.json()['score']==5
            client.post("/api/v1/system/worker/drain").raise_for_status()
            machine=client.get("/api/v1/machine-knowledge/units").json()[0]
            client.post(f"/api/v1/machine-knowledge/units/{machine['unit_id']}/reviews", json={
                "decision":"approve","reason":"smoke machine review","actor_id":"smoke",
                "idempotency_key":k('machine'),"expected_revision":machine['revision']}).raise_for_status()
            dashboard=client.get('/api/v1/dashboard').json()
            assert dashboard['pipeline'][-1]['status']=='approved'
            print('PASS: Research → Review → Knowledge → Learning → Mastery → Machine Knowledge')
            print(dashboard['metrics'])
    finally:
        shutil.rmtree(temp, ignore_errors=True)


if __name__ == '__main__': main()
