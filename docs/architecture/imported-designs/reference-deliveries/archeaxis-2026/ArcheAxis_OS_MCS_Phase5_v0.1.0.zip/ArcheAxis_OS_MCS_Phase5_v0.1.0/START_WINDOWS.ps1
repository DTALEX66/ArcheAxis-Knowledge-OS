$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$Python = Get-Command py -ErrorAction SilentlyContinue
if ($Python) {
    $PythonCmd = "py"
    $PythonArgs = @("-3")
} else {
    $Python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $Python) {
        throw "未找到 Python 3.10+。请先安装 Python，并勾选 Add Python to PATH。"
    }
    $PythonCmd = "python"
    $PythonArgs = @()
}

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "[ArcheAxis] 创建隔离虚拟环境..."
    & $PythonCmd @PythonArgs -m venv .venv
}

$VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"
Write-Host "[ArcheAxis] 校验并安装最小依赖..."
& $VenvPython -m pip install --disable-pip-version-check -q -r requirements.txt

Write-Host "[ArcheAxis] 启动元枢·观心 Phase 5 工作台：http://127.0.0.1:8010/"
Start-Process "http://127.0.0.1:8010/"
& $VenvPython -m archeaxis_mcs.server
