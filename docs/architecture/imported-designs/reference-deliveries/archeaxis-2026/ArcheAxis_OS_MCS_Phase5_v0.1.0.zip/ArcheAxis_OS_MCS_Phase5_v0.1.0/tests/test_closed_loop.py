from __future__ import annotations

import uuid

from fastapi.testclient import TestClient

from archeaxis_mcs.api import create_app


def key(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def test_phase5_minimum_closed_loop(tmp_path):
    app = create_app(tmp_path, embedded_worker=False)
    with TestClient(app) as client:
        seeded = client.post("/api/v1/demo/seed", json={"force_reset": False})
        assert seeded.status_code == 200
        research = client.get("/api/v1/research/packages").json()[0]
        assert research["status"] == "candidate"
        assert research["requires_human_review"] is True

        approve = {
            "decision": "approve",
            "reason": "来源、风险和候选边界已人工确认",
            "actor_id": "owner",
            "idempotency_key": key("research"),
            "expected_revision": research["revision"],
        }
        response = client.post(f"/api/v1/research/packages/{research['package_id']}/reviews", json=approve)
        assert response.status_code == 200
        assert client.post("/api/v1/system/worker/drain").json()["processed"] >= 1

        knowledge = client.get("/api/v1/knowledge/versions").json()
        learning = client.get("/api/v1/learning/artifacts").json()
        assert knowledge[0]["status"] == "active"
        assert learning[0]["status"] == "candidate"

        artifact = learning[0]
        response = client.post(
            f"/api/v1/learning/artifacts/{artifact['artifact_id']}/reviews",
            json={
                "decision": "approve",
                "reason": "练习目标与确定性 Rubric 一致",
                "actor_id": "reviewer",
                "idempotency_key": key("learning"),
                "expected_revision": artifact["revision"],
            },
        )
        assert response.status_code == 200

        valid = "元枢执行说明：\n- 固定来源版本并保存证据\n- 运行确定性约束验证\n- review_required=true 后进入人工审核"
        for _ in range(3):
            result = client.post(
                f"/api/v1/learning/artifacts/{artifact['artifact_id']}/practice",
                json={"response_text": valid, "actor_id": "learner", "idempotency_key": key("practice")},
            )
            assert result.status_code == 200
            assert result.json()["score"] == 5
        mastery = client.get("/api/v1/learning/mastery-signals").json()[0]
        assert mastery["is_mastered"] is True
        assert mastery["review_count"] == 3

        assert client.post("/api/v1/system/worker/drain").json()["processed"] >= 1
        machine = client.get("/api/v1/machine-knowledge/units").json()[0]
        assert machine["lifecycle_status"] == "candidate"
        assert machine["requires_human_review"] is True

        approve_machine = client.post(
            f"/api/v1/machine-knowledge/units/{machine['unit_id']}/reviews",
            json={
                "decision": "approve",
                "reason": "掌握信号、正式知识和权限边界完整",
                "actor_id": "owner",
                "idempotency_key": key("machine"),
                "expected_revision": machine["revision"],
            },
        )
        assert approve_machine.status_code == 200
        machine = client.get("/api/v1/machine-knowledge/units").json()[0]
        assert machine["lifecycle_status"] == "approved"
        assert machine["provenance_status"] == "server_verified"

        audit = client.get("/api/v1/system/audit").json()
        event_types = {item["event_type"] for item in audit}
        assert "ResearchPackageReviewed" in event_types
        assert "KnowledgeVersionActivated" in event_types
        assert "PracticeEvaluated" in event_types
        assert "MachineKnowledgeReviewed" in event_types


def test_idempotent_review_does_not_duplicate_fact(tmp_path):
    app = create_app(tmp_path, embedded_worker=False)
    with TestClient(app) as client:
        client.post("/api/v1/demo/seed", json={"force_reset": False})
        research = client.get("/api/v1/research/packages").json()[0]
        command = {
            "decision": "approve",
            "reason": "人工确认候选边界",
            "actor_id": "owner",
            "idempotency_key": "fixed-idempotency-key-0001",
            "expected_revision": research["revision"],
        }
        first = client.post(f"/api/v1/research/packages/{research['package_id']}/reviews", json=command)
        second = client.post(f"/api/v1/research/packages/{research['package_id']}/reviews", json=command)
        assert first.status_code == 200
        assert second.status_code == 200
        assert second.json()["idempotent_replay"] is True
        events = client.get("/api/v1/system/events").json()
        assert len(events) == 1
