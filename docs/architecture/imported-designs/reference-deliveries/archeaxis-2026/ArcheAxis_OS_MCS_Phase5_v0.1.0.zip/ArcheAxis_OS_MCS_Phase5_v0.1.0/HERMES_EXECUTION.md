# Hermes 执行命令｜Phase 5 MCS

你正在验收 `ArcheAxis_OS_MCS_Phase5_v0.1.0`。

## 目标

验证以下真实闭环，不扩展范围：

```text
Research Candidate → Human Review → KnowledgeVersion → LearningArtifact
→ 3x Deterministic Practice → MasterySignal → MachineKnowledge Candidate → Human Review
```

## 强制限制

- 只操作本交付包目录或 Cognitive-Loop-OS 的独立 feature worktree；
- 禁止删除项目目录外任何文件；
- 禁止自动 push、merge、release；
- 禁止恢复已移除的容器主运行栈；
- 禁止绑定或调用云模型；
- 禁止把 Candidate 自动提升为 Active/Approved；
- 禁止改写现有上游 SQLite；
- 失败必须显式报告。

## 执行

```bash
python -m pip install -e ".[dev]"
python -m pytest -q
python scripts/smoke_test.py
python scripts/verify_package.py
python -m archeaxis_mcs.server
```

## 验收输出

1. 测试结果；
2. 工作台截图；
3. `/api/v1/system/health`；
4. 完整审计导出；
5. 与主仓库合同/Facade 的差异清单；
6. 是否建议进入正式 Phase 5 feature branch；
7. 未完成项与回滚说明。
