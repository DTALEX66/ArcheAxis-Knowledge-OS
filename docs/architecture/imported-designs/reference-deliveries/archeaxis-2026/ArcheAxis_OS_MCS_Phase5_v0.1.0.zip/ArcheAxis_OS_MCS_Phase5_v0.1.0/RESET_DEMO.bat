@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m archeaxis_mcs.cli reset
) else (
  python -m archeaxis_mcs.cli reset
)
pause
