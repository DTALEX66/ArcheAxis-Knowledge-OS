# 验收清单

## Registry

- [ ] 顶层资产 ID 唯一
- [ ] 子资产 ID 唯一
- [ ] 标准仓库名完整
- [ ] 来源 revision 可追溯

## Security

- [ ] 默认网络拒绝
- [ ] 默认执行拒绝
- [ ] 无整仓 Google Research clone
- [ ] 无权重或数据自动下载
- [ ] 无项目外文件访问
- [ ] 无凭据写入仓库

## Research

- [ ] 首批 6 个子项目均有 ResearchProject
- [ ] 每个子项目有固定 revision
- [ ] 有许可证和外部资产说明
- [ ] Research 输出默认 Candidate

## Learning

- [ ] README 链接解析可离线运行
- [ ] URL 去重
- [ ] 资源类型可识别
- [ ] 第一批不超过 30 条
- [ ] 无自动正式课程

## Minimum Loop

- [ ] 完成一条 Research → Practice → Evidence 闭环
- [ ] 缺少证据时显式失败或阻塞
- [ ] Machine Knowledge 只能到 Candidate
- [ ] 人工批准前不得 Active
