#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^)\s]+)\)")

def normalize(url: str) -> str:
    p = urlsplit(url.strip())
    return urlunsplit((p.scheme.lower(), p.netloc.lower(), re.sub(r'/+$','',p.path), p.query, ''))

def classify(url: str) -> str:
    host = urlsplit(url).netloc.lower()
    if 'github.com' in host: return 'repository_or_github_resource'
    if 'kaggle.com' in host: return 'dataset_or_notebook'
    if 'medium.com' in host: return 'article'
    return 'web_resource'

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('readme', type=Path)
    ap.add_argument('--output', type=Path, default=Path('learning_candidates.json'))
    args = ap.parse_args()
    text = args.readme.read_text(encoding='utf-8')
    seen, rows = set(), []
    for label, raw in LINK_RE.findall(text):
        url = normalize(raw)
        if url in seen: continue
        seen.add(url)
        rows.append({'title':re.sub(r'\s+',' ',label).strip(),'source_url':url,'source_type':classify(url),'status':'discovered','execution_allowed':False,'automatic_promotion':False})
    args.output.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'extracted={len(rows)} output={args.output}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
