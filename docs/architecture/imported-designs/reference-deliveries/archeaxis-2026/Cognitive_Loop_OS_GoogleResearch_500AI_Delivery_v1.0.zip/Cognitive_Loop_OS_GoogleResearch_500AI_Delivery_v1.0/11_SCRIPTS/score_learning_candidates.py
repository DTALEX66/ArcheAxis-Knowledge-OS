#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
WEIGHTS={'relevance':25,'reproducibility':20,'teaching_value':15,'license_clarity':10,'documentation_quality':10,'maintenance_freshness':10,'compute_fit':5,'security':5}

def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('input',type=Path); ap.add_argument('--output',type=Path,default=Path('scored_candidates.json')); args=ap.parse_args()
    rows=json.loads(args.input.read_text(encoding='utf-8'))
    for item in rows:
        score=0.0
        for name, weight in WEIGHTS.items():
            value=float(item.get('ratings',{}).get(name,0))
            if not 0 <= value <= 1: raise ValueError(f'{name} must be 0..1')
            score += value*weight
        item['score']=round(score,2)
        item['status']='approved_candidate' if score>=80 else 'learning_scored' if score>=65 else 'reference_only' if score>=50 else 'archived'
    args.output.write_text(json.dumps(rows, ensure_ascii=False, indent=2),encoding='utf-8')
    print(f'scored={len(rows)} output={args.output}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
