# 最小闭环建议

首选：`instruction_following_eval`

1. 建立 ResearchProject。
2. 提取“指令约束可验证”方法。
3. 生成 Knowledge Unit。
4. 定义 5 类 InstructionConstraint。
5. 创建 Learning Project：实现 5 个确定性验证器。
6. 在隔离环境运行测试。
7. 生成 Practice Evidence。
8. 生成 Mastery Signal。
9. 生成 Machine Knowledge Candidate。
10. 人工审核后才可供 Planner 使用。

通过标准：来源固定、结果可重复、证据完整、可回滚、不得自动 Active。
