# 500 AI 链接清洗任务

```text
Markdown Table
→ Link Extraction
→ URL Normalization
→ Resource Typing
→ Deduplication
→ Metadata Verification
→ License Review
→ Maintenance Review
→ Learning Score
→ Human Review
→ LearningProjectCandidate
```

第一阶段最多 30 条，不下载数据、不运行代码、不自动创建正式课程。
