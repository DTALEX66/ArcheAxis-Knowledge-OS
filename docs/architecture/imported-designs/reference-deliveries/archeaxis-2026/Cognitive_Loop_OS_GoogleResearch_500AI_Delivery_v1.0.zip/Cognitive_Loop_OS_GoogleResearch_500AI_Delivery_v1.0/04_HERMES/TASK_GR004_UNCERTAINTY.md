# GR-004 不确定性与人工升级

必须分离：

- 模型置信度
- 证据充分度
- 事实可信度
- 执行成功率
- 风险等级

支持状态：

- verified
- likely
- uncertain
- conflicted
- out_of_scope
- needs_more_evidence
- needs_human_review
- abstained

高风险且证据不足时必须升级人工审核。
