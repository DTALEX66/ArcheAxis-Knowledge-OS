# GR-002 SayCan 规划思想吸收

## 目标

让 Planner 的候选动作受到工具能力、环境、权限、风险和证据约束。

## 交付

- ToolAffordance
- ToolPrecondition
- EnvironmentState
- FeasibilityAssessment
- 候选步骤排序与过滤接口

## 必测场景

1. 工具不存在。
2. 路径未授权。
3. 缺少前置文件。
4. 高风险操作未批准。
5. 没有成功证据定义。

语义合理但实际不可执行的步骤不得进入执行队列。
