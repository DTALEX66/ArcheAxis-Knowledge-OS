# GR-001 DatasetAgent 方法吸收

## 目标

提取事件发现、抓取预算、证据清洗、验证与运行状态设计。

## 交付

- ResearchRun
- SearchPlan
- QueryBudget
- CandidateEvent
- ValidationTask
- ResearchState
- 无网络配置校验

## 不交付

- Google Custom Search 真接入
- Gemini 强依赖
- Playwright 在线抓取
- 全量代码移植

## 验收

- 查询预算显式可见。
- 发现和验证分离。
- 无网络时可校验配置。
- 输出不写入源代码目录。
