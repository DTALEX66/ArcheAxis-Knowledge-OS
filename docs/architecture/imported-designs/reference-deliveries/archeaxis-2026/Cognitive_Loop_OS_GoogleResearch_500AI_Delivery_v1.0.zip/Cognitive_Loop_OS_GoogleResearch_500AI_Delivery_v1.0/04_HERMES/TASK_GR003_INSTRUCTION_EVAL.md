# GR-003 Instruction Constraint Evaluation

## 目标

把用户要求拆成可验证约束，替代“模型认为已完成”。

## 首批验证器

- file_exists
- file_changed
- contains_text
- excludes_text
- test_exit_code
- schema_valid
- count_equals
- path_access_audit
- evidence_present

## 验收

缺少任一强制证据时，任务不得返回 success。
