# Hermes 主执行命令

你正在 `DTALEX66/Cognitive-Loop-OS` 中执行“Google Research 与 500 AI Projects 治理接入”。

## 总目标

建立：

1. Google Research 子项目级研究资产摄取。
2. 500 AI 外部链接级学习资源清洗。
3. 一条 Research-to-Practice 最小闭环。

## 强制限制

- 只允许操作当前项目目录和任务 Worktree。
- 禁止删除项目目录外任何文件。
- 禁止访问用户原始资料盘。
- 禁止整仓 clone/vendor Google Research。
- 禁止下载权重和大型数据集。
- 禁止运行未经审查的第三方代码。
- 禁止自动 push、merge、release。
- 禁止把模型输出直接写成 Active Knowledge。
- 所有新对象必须有来源、版本、状态、证据和回滚路径。
- 失败必须显式失败，不得伪造完成。

## Phase A：资产注册

- 合并注册表 Patch。
- 新增 Google Research 子资产注册表。
- 新增 Learning Resource Collection。
- 增加 ID 唯一性测试。

## Phase B：Contracts

至少实现：

- `ResearchProject`
- `ExperimentSpec`
- `ReproducibilityReport`
- `LearningProjectCandidate`
- `LearningProject`
- `InstructionConstraint`
- `VerificationResult`
- `ToolAffordance`
- `FeasibilityAssessment`
- `AbstentionDecision`

## Phase C：Google Research Intake

- 只处理首批 6 个子项目。
- 固定来源 Commit SHA。
- 记录 README、论文、许可证、依赖与维护状态。
- 默认不执行。
- 生成 Research Package。

## Phase D：500 AI Link Intake

- 离线解析 README。
- URL 规范化和去重。
- 识别仓库、文章、课程、数据集和二级集合。
- 第一阶段最多保留 30 条。
- 输出 `LearningProjectCandidate`。

## Phase E：最小闭环

首选 `instruction_following_eval`：

```text
Research Package
→ Knowledge Unit
→ InstructionConstraint
→ Learning Project
→ Sandbox Practice
→ Practice Evidence
→ Evaluation Report
→ Machine Knowledge Candidate
```

## 输出

- Patch
- 测试报告
- 变更清单
- 风险清单
- 未完成项
- 回滚说明
- 来源台账
