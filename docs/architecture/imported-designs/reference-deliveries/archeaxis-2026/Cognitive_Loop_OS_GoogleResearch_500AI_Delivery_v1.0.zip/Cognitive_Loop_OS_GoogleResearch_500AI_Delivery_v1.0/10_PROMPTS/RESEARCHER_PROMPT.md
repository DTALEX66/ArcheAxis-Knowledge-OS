# Researcher Prompt

分析一个 Google Research 子项目，必须输出：

- 固定 revision
- 论文与 README
- 问题、输入、输出与实验流程
- 数据、模型和外部服务依赖
- 许可证
- 维护状态
- 可吸收的方法
- 不应吸收的代码
- 对 OS 的模块映射
- 风险与未知项

禁止运行代码、下载权重或把摘要当作复现。
