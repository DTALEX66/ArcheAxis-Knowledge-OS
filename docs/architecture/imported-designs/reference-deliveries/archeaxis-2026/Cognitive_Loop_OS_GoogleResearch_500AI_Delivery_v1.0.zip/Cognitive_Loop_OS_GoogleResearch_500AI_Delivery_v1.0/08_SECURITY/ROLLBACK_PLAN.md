# 回滚方案

- 注册表采用追加 Patch，不覆盖旧记录。
- 新 Schema 采用版本化文件。
- 新字段初期 optional，迁移后再收紧。
- 新对象使用独立表或独立 owner。
- Planner/Evaluator 增强使用 Feature Flag，默认关闭。
- 外部代码只存在于临时 Worktree/容器，删除任务环境即可回滚。
- 正式仓库不保存大型代码、数据和权重。
