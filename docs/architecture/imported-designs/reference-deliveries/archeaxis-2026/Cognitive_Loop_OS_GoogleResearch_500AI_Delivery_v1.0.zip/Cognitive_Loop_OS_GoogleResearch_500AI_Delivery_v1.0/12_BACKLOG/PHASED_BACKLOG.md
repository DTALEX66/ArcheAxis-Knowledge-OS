# 分阶段 Backlog

## P0 治理基础

- [ ] 注册两个顶层资产
- [ ] 注册 6 个子资产
- [ ] 新增 Schema 与状态机
- [ ] 来源 revision 与默认执行拒绝

## P0 最小闭环

- [ ] IFEval → InstructionConstraint
- [ ] 5 个确定性验证器
- [ ] 一个 Learning Project
- [ ] 一个 Sandbox Practice
- [ ] Practice Evidence
- [ ] Machine Knowledge Candidate

## P1 Research

- [ ] 查询预算
- [ ] 发现/验证分离
- [ ] ResearchRun 状态恢复
- [ ] 多来源冲突记录

## P1 Runtime / Evaluation

- [ ] ToolAffordance
- [ ] FeasibilityAssessment
- [ ] Abstention
- [ ] Human Review Queue
- [ ] Scenario Tests

## P2 Learning Library

- [ ] 清洗 20–30 条链接
- [ ] 技能节点
- [ ] 课程缺口
- [ ] 实践任务队列
