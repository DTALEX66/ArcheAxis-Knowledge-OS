# Definition of Done

任务只有同时满足以下条件才算完成：

- 实际产物存在。
- Schema 验证通过。
- 测试通过。
- 有固定来源 revision。
- 有证据、风险和回滚方法。
- 无越权路径访问。
- 无未经审批的网络或代码执行。
- Candidate 未自动晋升 Active。
- 报告真实列出未完成项。
