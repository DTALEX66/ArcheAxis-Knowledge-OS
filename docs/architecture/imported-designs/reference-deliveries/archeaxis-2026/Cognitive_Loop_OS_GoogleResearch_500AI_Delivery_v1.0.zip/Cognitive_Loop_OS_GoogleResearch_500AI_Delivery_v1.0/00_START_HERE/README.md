# Cognitive Loop OS 外部研究与学习资产吸收交付包

版本：v1.0  
目标仓库：`DTALEX66/Cognitive-Loop-OS`

本包用于治理性接入：

- `google-research/google-research`
- `ashishpatel26/500-AI-Machine-learning-Deep-learning-Computer-vision-NLP-Projects-with-code`

## 核心结论

### Google Research

定位为 **科研资产总源**，处理单位是“子项目”，只允许固定版本、选择性研究、隔离复现，不允许整仓吸收。

### 500 AI Projects

定位为 **学习资源链接索引**，处理单位是“单条链接”，只用于资源发现、课程缺口分析和实践项目候选，不允许自动运行和自动晋升正式知识。

## 推荐执行顺序

1. 合并资产注册表补丁。
2. 建立新增 Contracts 与状态机。
3. 处理首批 6 个 Google Research 子项目。
4. 离线解析 500 AI README，第一批最多保留 30 条候选。
5. 完成一条“研究 → 知识 → 实践 → 证据 → 机器知识候选”最小闭环。
6. 按验收清单复核。

## 强制禁止

- 禁止整仓 vendor Google Research。
- 禁止自动下载权重、数据集和 Checkpoint。
- 禁止自动执行 500 AI 目录中的第三方代码。
- 禁止把外部标题、Star 或模型摘要直接视为可信知识。
- 禁止修改项目目录之外的文件。
- 禁止自动 push、merge、release。
