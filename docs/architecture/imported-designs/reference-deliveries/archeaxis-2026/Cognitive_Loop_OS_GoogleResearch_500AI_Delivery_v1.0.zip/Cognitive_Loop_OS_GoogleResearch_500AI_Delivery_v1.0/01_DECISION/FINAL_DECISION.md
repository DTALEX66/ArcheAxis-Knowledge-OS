# 最终吸收决策

## 1. google-research/google-research

- 资产类型：`research_super_repository`
- 优先级：P1
- 默认执行：拒绝
- Clone 策略：固定 Commit，仅 sparse/subdirectory
- 自动知识晋升：拒绝

### 首批子项目

| 子项目 | 目标模块 | 优先级 | 主要价值 |
|---|---|---:|---|
| `TimesX/dataset_agent` | Inspiration Research | P0 | 事件发现、查询预算、抓取、证据清洗、验证与运行状态 |
| `saycan` | Cognitive Runtime / Planner | P0 | 基于技能与环境可行性的规划约束 |
| `instruction_following_eval` | Evaluation Engine | P0 | 将用户指令拆成可验证约束 |
| `active_selective_prediction` | Governance / Human Review | P1 | 不确定时拒答、选择性执行与人工升级 |
| `behavioral_dispositions` | Model & Agent Evaluation | P1 | 情景测试、多次运行与行为分布 |
| `uq_benchmark_2019` | Evaluation | P1 | 校准、分布变化与不确定性评测 |

## 2. 500 AI Projects

- 资产类型：`learning_resource_index`
- 优先级：P2
- 默认执行：拒绝
- 初期读取范围：README
- 自动课程晋升：拒绝

### 第一批只筛选

- Agent
- RAG
- Knowledge Graph
- Memory
- Document Intelligence
- Evaluation
- Local-first AI
- AI Workspace
- Research Agent
- MLOps

## 总体目标

建立 **Research-to-Practice Bridge**：

```text
科研成果
→ Research Package
→ Knowledge Unit
→ Skill Node
→ Learning Project
→ Sandbox Practice
→ Practice Evidence
→ Mastery Signal
→ Machine Knowledge Candidate
```
