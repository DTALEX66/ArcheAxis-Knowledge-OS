# 新增对象模型

## Research

- `ResearchCollection`
- `ResearchProject`
- `PaperRecord`
- `ResearchRun`
- `SearchPlan`
- `QueryBudget`
- `CandidateEvent`
- `EvidenceSource`
- `EvidenceFragment`
- `ValidationTask`
- `ConflictRecord`
- `ExperimentSpec`
- `BenchmarkSpec`
- `ReproducibilityReport`

## Learning

- `LearningResourceCollection`
- `LearningProjectCandidate`
- `LearningProject`
- `SkillNode`
- `CurriculumGap`
- `PracticeEvidence`
- `MasterySignal`

## Runtime / Evaluation

- `ToolCapability`
- `ToolPrecondition`
- `ToolAffordance`
- `EnvironmentState`
- `FeasibilityAssessment`
- `InstructionConstraint`
- `Verifier`
- `VerificationResult`
- `UncertaintyAssessment`
- `AbstentionDecision`
- `HumanReviewRequest`
- `ScenarioTest`
- `RepeatedRunDistribution`

## 通用治理字段

所有对象必须支持：

- ID 与 Schema Version
- 状态
- 来源与固定 revision
- 证据
- 风险
- 审核记录
- 生命周期
- 替代关系
- 回滚路径
