# 状态机

## ResearchProject

```text
discovered
→ indexed
→ metadata_verified
→ license_reviewed
→ architecture_reviewed
→ sandbox_ready
→ reproduced
→ accepted_reference
→ deprecated
```

## LearningProjectCandidate

```text
discovered
→ url_validated
→ typed
→ deduplicated
→ metadata_verified
→ learning_scored
→ human_reviewed
→ approved_candidate
→ active_learning_project
→ archived
```

## Knowledge Promotion

```text
draft
→ candidate
→ reviewed
→ approved
→ active
→ deprecated
→ revoked
```

禁止跨状态自动晋升。
