# Research-to-Practice Bridge

## 科研输入链

```text
Research Repository
→ Subproject
→ Paper / README / Code Structure
→ ResearchProject
→ ExperimentSpec
→ BenchmarkSpec
→ ReproducibilityReport
```

## 学习输入链

```text
Resource Index
→ Link Extraction
→ URL Normalization
→ Resource Typing
→ Deduplication
→ Metadata Review
→ LearningProjectCandidate
→ Human Review
→ LearningProject
```

## 进化闭环

```text
Research Method
→ Knowledge Unit
→ Learning Project
→ Practice Evidence
→ Mastery Signal
→ Machine Knowledge Candidate
→ Planner / Evaluator Improvement
```

## 隔离原则

- 外部科研代码不进入正式核心运行环境。
- 外部链接不直接进入正式知识库。
- Candidate 与 Active 严格分离。
- 复现环境使用一次性 Worktree + Docker。
- Judge 模型不替代确定性验证器。
