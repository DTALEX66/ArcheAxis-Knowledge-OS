# Reproducibility Report

- Project:
- Source revision:
- Environment:
- Date:

## Scope

## Inputs

## Procedure

## Commands / Exit Codes / Logs / Hashes

## Result

- Status: reproduced / partial / failed / blocked
- Differences from upstream:
- Risks:
- Follow-up:
